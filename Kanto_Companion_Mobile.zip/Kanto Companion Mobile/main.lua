return function(mod)
  -- =====================================================================
  -- Kanto In-Game Companion -- draws the same panels as the streaming mod
  -- (Kanto Stream Companion) but INSIDE the game with love.graphics, on top
  -- of the widescreen view. No server / threads / browser: it reads game.save
  -- each frame and draws. Toggle with F8. READ-ONLY.
  --
  -- State lives on a global so F5 hot-reload re-runs this file without
  -- re-wrapping love.draw / game.update / game.keypressed.
  -- =====================================================================

  -- Shows a small "last input -> ..." readout in the bottom-left corner for a
  -- few seconds after any key/gamepad/touch event, so you can see exactly
  -- what Gen1Recomp's built-in touch controls (e.g. the touch Select button)
  -- report on a device with no log access. Toggle from the mod manager
  -- (Options > Kanto Companion) -- no need to edit this file anymore.
  mod.options:define({
    { key = "debug_input_hud", type = "toggle", label = "DEBUG INPUT HUD", default = false },
    { key = "touch_nav_buttons", type = "toggle", label = "TOUCH SCREEN NAV BUTTONS", default = false },
  })
  mod.events:on("mod.options_changed", function(p)
    if p and p.mod == mod.id and p.key == "debug_input_hud" then
      mod.log:info("kanto_companion: debug input HUD %s", p.value and "enabled" or "disabled")
    end
  end)
  local OVERLAY_KEYS = { o = true, f8 = true }   -- toggle the passive overlay
  local ITEMS_KEY    = "i"                         -- Bag <-> PC items screen
  local PARTY_KEY    = "p"                         -- Party <-> PC boxes screen

  -- Gamepad mapping (Odin 2 Portal built-in controller, standard SDL layout).
  -- Values are LOVE GamepadButton names -> the keyboard key they stand in for,
  -- so they run through the exact same onKeyDown / onScreenKey logic as the
  -- keyboard hotkeys above. L2/R2 aren't here: LOVE reports analog triggers
  -- as axes, not buttons, so they're wired separately (see love.gamepadaxis
  -- near the bottom). R2 (triggerright) doubles as the overlay toggle from
  -- the overworld (replaces the old R1/rightshoulder mapping) and, on the
  -- Items screen, still drives C.onPadTrigger for held-item quantity --
  -- see the gamepadaxis wrapper for how those two stay separate.
  local PAD_KEYMAP = {
    y            = "p",         -- Y: Party / Boxes screen
    x            = "i",         -- X: Items screen
    b            = "escape",    -- B: close whichever screen is open
    dpleft       = "left",      -- D-pad left/right: cycle box view (Party screen)
    dpright      = "right",
  }
  -- Select / touchpad-click button, Gen1Recomp's Tab/Shift keys, and a
  -- touch hot-zone over the hardware Select button used to all trigger this
  -- same screen-cycle too (overlay -> items -> party -> closed). That's been
  -- removed -- the cycle is now driven only by the two on-screen touch-nav
  -- buttons below (TOUCH_NAV_LEFT/RIGHT) and C.onPadCycle.
  -- Two custom-drawn on-screen buttons (left/right arrows) that step through
  -- the same overlay -> items -> party -> closed cycle Select used to, but
  -- forward OR backward and via touch anywhere on screen -- no reliance on
  -- Gen1Recomp's built-in touch Select ever firing an event we can see. Off
  -- by default; enable via mod options ("TOUCH SCREEN NAV BUTTONS"). Defined
  -- as percent-of-window rectangles so position holds across screen sizes.
  -- These are drawn buttons (see C.drawTouchNav below), so the touch zone
  -- and the visible box are always the same rectangle -- what you see is
  -- exactly what's tappable. Calibrated from a screenshot at 1920x1080:
  -- the Select ("-") and Start ("+") circles centered at roughly x=895 and
  -- x=1023 (y~930) on that device -- these boxes sit centered on those same
  -- x's, just above that row (y ~687-765px there -- pulled down closer to
  -- Select/Start than the original placement, still with a clear gap so
  -- they don't overlap). Because Select and Start are close together and
  -- the boxes are narrow (~100px) to avoid overlapping each other, this
  -- centers precisely rather than just "roughly above" -- but it's still
  -- only confirmed accurate on that one screenshot's layout. If it's off
  -- on your device, tap where Select/Start actually are with the debug
  -- input HUD on, read the touch percentages off the HUD, and recenter
  -- x1/x2 on those (and nudge y1/y2 the same way to re-tune this offset).
  local TOUCH_NAV_LEFT  = { x1 = 0.4401, y1 = 0.6365, x2 = 0.4922, y2 = 0.7087 }  -- left arrow: previous screen (centered over Select)
  local TOUCH_NAV_RIGHT = { x1 = 0.5068, y1 = 0.6365, x2 = 0.5589, y2 = 0.7087 }  -- right arrow: next screen (centered over Start)
  local REF_H      = 1440        -- design reference height; everything scales off this
  local INTERVAL   = 0.12        -- seconds between save reads

  -- The overlay's scale (s, below) is normally just window-height / REF_H, which
  -- keeps proportions consistent across resolutions but doesn't account for
  -- physical screen size. On a small high-DPI panel like the Odin 2 Portal's
  -- 7" 1920x1080 display, that math alone still produces cramped, hard-to-read
  -- text and tight spacing. UI_SCALE_OVERLAY is an extra multiplier on top of
  -- that ratio -- since fonts, padding, margins, and panel sizes all route
  -- through the same scale factor, bumping this one number enlarges and
  -- spaces out everything in the overlay together. Raise it further for more
  -- room to breathe, lower it if things start crowding the screen edges.
  local UI_SCALE_OVERLAY = 1.5

  -- Same idea, applied to the Items and Party/Boxes modal screens (drawScreen
  -- and its input handlers below). Kept as a separate knob from the overlay's
  -- in case the two ever need different values.
  local UI_SCALE_SCREEN = 1.5

  local C = _G.__KANTO_INGAME or {}
  _G.__KANTO_INGAME = C
  if C.visible == nil then C.visible = false end   -- off by default; press 'o' to show
  if C.partyStyle == nil then C.partyStyle = 1 end   -- 1 = full, 2 = compact (F7)
  C.fonts   = C.fonts or {}
  C.sprites = C.sprites or {}
  C.dispHP  = C.dispHP or {}      -- animated HP values keyed by "p1".."p6"/"enemy"
  C.dispSp  = C.dispSp or {}      -- species behind each animated value (reset on change)
  C.triggerDown = C.triggerDown or { triggerleft = false, triggerright = false }  -- L2/R2 latch, Items screen qty

  -- engine modules (same sources the streaming mod uses)
  local function req(p) local ok, m = pcall(require, p); return ok and m or nil end
  C.game     = C.game or req("src.core.Game")
  C.TypeChart = C.TypeChart or req("src.battle.TypeChart")
  C.Catching = C.Catching or req("src.battle.Catching")
  C.Growth   = C.Growth or req("src.pokemon.Growth")
  C.Badges   = C.Badges or req("src.inventory.Badges")
  C.BattleState = C.BattleState or req("src.battle.BattleState")
  C.Boxes    = C.Boxes or req("src.pokemon.Boxes")
  C.Party    = C.Party or req("src.pokemon.Party")
  C.Bag      = C.Bag or req("src.inventory.Bag")
  C.Stats    = C.Stats or req("src.pokemon.Stats")
  mod.events:on("game.ready", function(p) C.game = (p and p.game) or C.game end)

  -- ---------------------------------------------------------------------
  -- Palette (0..1)
  -- ---------------------------------------------------------------------
  local function hex(s)
    return { tonumber(s:sub(1,2),16)/255, tonumber(s:sub(3,4),16)/255, tonumber(s:sub(5,6),16)/255 }
  end
  local COL = {
    panel = hex("10121a"), border = hex("ffffff"),
    text = hex("ffffff"), dim = hex("b9bdc9"),
    hi = hex("7dd87d"), mid = hex("e6d24a"), lo = hex("e05a5a"),
    xp = hex("5ab0ff"), gold = hex("ffd54a"), money = hex("ffe27a"),
    barbg = hex("ffffff"), threat = hex("ffb38a"),
    super = hex("7dd87d"), resist = hex("e0906a"),
  }
  local TYPE = {
    NORMAL=hex("9a9a80"), FIRE=hex("e0632c"), WATER=hex("3a86e8"), ELECTRIC=hex("e0b330"),
    GRASS=hex("5fb04a"), ICE=hex("5fc7c7"), FIGHTING=hex("b23a2e"), POISON=hex("8a3a9a"),
    GROUND=hex("c8a84a"), FLYING=hex("7a8fe0"), PSYCHIC=hex("e0508a"), BUG=hex("8a9a20"),
    ROCK=hex("a89440"), GHOST=hex("5a4a8a"), DRAGON=hex("5a4ae0"),
  }

  -- ---------------------------------------------------------------------
  -- Cheap caches: scaled fonts + species sprites
  -- ---------------------------------------------------------------------
  local function getFont(sizePx)
    sizePx = math.max(8, math.floor(sizePx))
    local f = C.fonts[sizePx]
    if not f then f = love.graphics.newFont(sizePx); C.fonts[sizePx] = f end
    return f
  end
  local function getSprite(speciesId, dPoke)
    if C.sprites[speciesId] ~= nil then return C.sprites[speciesId] or nil end
    local def = dPoke[speciesId]
    local rel = def and def.spriteFront
    local img = false
    if rel then local ok, i = pcall(love.graphics.newImage, rel); if ok then img = i end end
    C.sprites[speciesId] = img
    return img or nil
  end

  -- Gym-badge spritesheet (16px wide; each gym badge tile is at (0, i*32+16),
  -- in the same gym order as Badges.list). Cached; nearest-filtered for crisp
  -- pixels when scaled up.
  local function badgeSheet()
    if C.badgeSheet == nil then
      local ok, img = pcall(love.graphics.newImage, "assets/generated/trainer_card/badges.png")
      if ok and img then
        img:setFilter("nearest", "nearest")
        local iw, ih = img:getDimensions()
        local q = {}
        for i = 0, 7 do q[i] = love.graphics.newQuad(0, i * 32 + 16, 16, 16, iw, ih) end
        C.badgeSheet = { img = img, quads = q }
      else
        C.badgeSheet = false
      end
    end
    return C.badgeSheet or nil
  end

  -- Item classification for the Items panel (Gen 1 has no bag pockets, so we
  -- sort by id ourselves). Balls = anything with BALL; Healing = HP/PP/status.
  local HEAL_IDS = {
    POTION=true, SUPER_POTION=true, HYPER_POTION=true, MAX_POTION=true, FULL_RESTORE=true,
    FULL_HEAL=true, ANTIDOTE=true, BURN_HEAL=true, ICE_HEAL=true, AWAKENING=true, PARLYZ_HEAL=true,
    REVIVE=true, MAX_REVIVE=true, ETHER=true, MAX_ETHER=true, ELIXER=true, MAX_ELIXER=true,
    FRESH_WATER=true, SODA_POP=true, LEMONADE=true,
  }
  local function isBallItem(id) return id:find("BALL", 1, true) ~= nil end
  local function isHealItem(id)
    return HEAL_IDS[id]
      or id:find("POTION", 1, true) or id:find("HEAL", 1, true) or id:find("REVIVE", 1, true)
      or id:find("RESTORE", 1, true) or id:find("ETHER", 1, true) or id:find("ELIXER", 1, true)
  end

  -- ---------------------------------------------------------------------
  -- STATE: read game.save into a small table we can draw (ported/trimmed
  -- from the streaming snapshot; no JSON, keeps species ids for sprites).
  -- ---------------------------------------------------------------------
  local function currentBattle()
    local g = C.game; local stk = g and g.stack
    if not (stk and stk.states and C.BattleState) then return nil end
    for i = #stk.states, 1, -1 do
      if getmetatable(stk.states[i]) == C.BattleState then return stk.states[i] end
    end
    return nil
  end

  local function buildState()
    local game = C.game
    local save = game and game.save
    if not save then return nil end
    local data  = game.data or {}
    local dPoke = data.pokemon or {}
    local dMove = data.moves or {}
    local dItem = data.items or {}
    C.dPoke = dPoke

    local function dispTypes(raw)
      local o = {}
      for _, t in ipairs(raw or {}) do o[#o+1] = (C.TypeChart and C.TypeChart.displayName(t)) or t end
      return o
    end
    local function brief(mon)
      if not mon then return nil end
      local d = dPoke[mon.species]
      return {
        name = mon.nickname or (d and d.name) or tostring(mon.species),
        species = mon.species, level = mon.level, hp = mon.hp,
        maxhp = mon.stats and mon.stats.hp, status = mon.status or "OK",
        types = dispTypes(d and d.types),
      }
    end

    local battle = currentBattle()
    local activeMon = battle and battle.player and battle.player.mon or nil
    local teamTypes = {}

    -- party
    local party = {}
    for i, mon in ipairs(save.party or {}) do
      local def = dPoke[mon.species]
      local moves = {}
      for _, mv in ipairs(mon.moves or {}) do
        local md = dMove[mv.id]
        moves[#moves+1] = { name = (md and md.name) or mv.id, pp = mv.pp, maxpp = md and md.pp }
      end
      local raw = (def and def.types) or {}
      if #raw > 0 then teamTypes[#teamTypes+1] = raw end
      local xpProg, xpNext
      if C.Growth and def and def.growthRate and mon.exp and mon.level then
        local rates = data.growth_rates
        local cur = C.Growth.expForLevel(def.growthRate, mon.level, rates)
        local nxt = C.Growth.expForLevel(def.growthRate, mon.level + 1, rates)
        if mon.level >= 100 or nxt <= cur then xpProg, xpNext = 1, 0
        else xpProg = math.max(0, math.min(1, (mon.exp - cur)/(nxt - cur))); xpNext = math.max(0, nxt - mon.exp) end
      end
      party[i] = {
        slot = i, name = mon.nickname or (def and def.name) or tostring(mon.species),
        species = mon.species, level = mon.level, hp = mon.hp,
        maxhp = mon.stats and mon.stats.hp, status = mon.status or "OK",
        types = dispTypes(raw), moves = moves, exp = mon.exp,
        xpProgress = xpProg, xpToNext = xpNext,
        active = (activeMon ~= nil and mon == activeMon) or nil,
      }
    end

    -- trainer
    local badges, badgeCount = {}, 0
    if C.Badges and data then
      for i, e in ipairs(C.Badges.list(data)) do
        local owned = save.inventory[C.Badges.itemFor(e)] and true or false
        if owned then badgeCount = badgeCount + 1 end
        local id = e.id or ("BADGE"..i); local base = id:gsub("BADGE$", "")
        badges[i] = { name = e.name or (base:sub(1,1)..base:sub(2):lower()), owned = owned }
      end
    end
    local dex = save.pokedex or {}
    local function countTrue(t) local n=0; if t then for _,v in pairs(t) do if v then n=n+1 end end end; return n end
    local dexTotal = 0
    for _, d in pairs(dPoke) do if d.dex and d.dex > dexTotal then dexTotal = d.dex end end
    local trainer = {
      name = (save.player and save.player.name) or "", money = save.money or 0,
      version = save.version or "", playTime = math.floor(save.playTime or 0),
      badges = badges, badgeCount = badgeCount, dexSeen = countTrue(dex.seen),
      dexOwned = countTrue(dex.owned), dexTotal = dexTotal > 0 and dexTotal or nil,
      partyCount = #(save.party or {}),
    }

    -- route (grass + surf)
    local BK = (data.constants and data.constants.encounterBuckets)
      or { 51,102,141,166,191,216,229,242,253,256 }
    local function encTable(part)
      if not part or not part.slots or (part.rate or 0) == 0 then return nil end
      local bk = part.buckets or BK
      local agg, order, prev = {}, {}, 0
      for i, slot in ipairs(part.slots) do
        local top = bk[i] or 256; local w = top - prev; prev = top
        if slot and slot.species then
          local a = agg[slot.species]
          if not a then a = { species = slot.species, weight = 0, minL = slot.level, maxL = slot.level }; agg[slot.species]=a; order[#order+1]=a end
          a.weight = a.weight + w; a.minL = math.min(a.minL, slot.level); a.maxL = math.max(a.maxL, slot.level)
        end
      end
      local list = {}
      for _, a in ipairs(order) do
        local d = dPoke[a.species]
        list[#list+1] = { name = (d and d.name) or tostring(a.species), species = a.species,
          pct = math.floor(a.weight/256*100 + 0.5), minLevel = a.minL, maxLevel = a.maxL }
      end
      table.sort(list, function(x,y) return x.pct > y.pct end)
      return { rate = math.floor((part.rate or 0)/256*100 + 0.5), species = list }
    end
    local route
    local ov = game.overworld
    local mapId = ov and ov.map and ov.map.id
    if mapId then
      route = { name = (mapId:lower():gsub("_"," "):gsub("(%a)(%w*)", function(a,b) return a:upper()..b end)) }
      local enc = (data.encounters or {})[mapId]
      if enc then route.grass = encTable(enc.grass); route.water = encTable(enc.water) end
    end

    -- battle + matchup + catch
    local battleBlock
    if battle then
      local pMon, eMon = battle.player and battle.player.mon, battle.enemy and battle.enemy.mon
      local myTypes = (pMon and dPoke[pMon.species] and dPoke[pMon.species].types) or {}
      local enTypes = (eMon and dPoke[eMon.species] and dPoke[eMon.species].types) or {}
      local matchup
      if C.TypeChart and pMon and eMon then
        if not C.tcReady then C.tcReady = pcall(C.TypeChart.load, data) end
        local ok, res = pcall(function()
          local eff, disp, cat = C.TypeChart.effectiveness, C.TypeChart.displayName, C.TypeChart.category
          local function has(l,t) for _,x in ipairs(l) do if x==t then return true end end return false end
          local myMoves, bi, bs = {}, nil, -1
          for _, mv in ipairs(pMon.moves or {}) do
            local md = dMove[mv.id]
            if md then
              local pow = md.power or 0
              local st = (md.category == "status") or pow == 0
              local mult = eff(md.type, enTypes); local stab = has(myTypes, md.type)
              myMoves[#myMoves+1] = { name = md.name or mv.id, type = disp(md.type),
                power = pow > 0 and pow or nil, pp = mv.pp, maxpp = md.pp,
                mult = mult, stab = stab or nil, status = st or nil }
              if not st and mult > 0 then local sc = mult*pow*(stab and 15 or 10); if sc > bs then bs=sc; bi=#myMoves end end
            end
          end
          if bi then myMoves[bi].best = true end
          local threats = {}
          for _, mv in ipairs(eMon.moves or {}) do
            local md = dMove[mv.id]
            if md and md.category ~= "status" and (md.power or 0) > 0 then
              local mult = eff(md.type, myTypes)
              if mult > 10 then threats[#threats+1] = { name = md.name or mv.id, type = disp(md.type), mult = mult } end
            end
          end
          table.sort(threats, function(a,b) return a.mult > b.mult end)
          local mS, eS = pMon.stats and pMon.stats.speed, eMon.stats and eMon.stats.speed
          local faster; if mS and eS then faster = (mS>eS) and "you" or ((eS>mS) and "them" or "tie") end
          return { speed = { faster = faster }, myMoves = myMoves, threats = threats }
        end)
        if ok then matchup = res end
      end
      -- catch odds (wild)
      local catch
      if battle.kind == "wild" and eMon then
        local okc, res = pcall(function()
          local eDef = dPoke[eMon.species]; local rate = eDef and eDef.catchRate
          local maxhp = eMon.stats and eMon.stats.hp; local hp = eMon.hp
          if not (rate and maxhp and hp) then return nil end
          local s = eMon.status
          local sb = (s=="SLP" or s=="FRZ") and 25 or (s and 12 or 0)
          local bd = data.balls
          local function def(id) return (bd and bd[id]) or (C.Catching and C.Catching.BALLS and C.Catching.BALLS[id]) end
          local function odds(d)
            if not d then return nil end
            if d.autoCatch then return 100 end
            local rm, hf = d.randMax, d.hpFactor; if not (rm and hf) then return nil end
            local N = rm + 1; local hq = math.max(1, math.floor(hp/4))
            local f = math.min(255, math.floor(math.floor(maxhp*255/hf)/hq))
            local p1 = sb/N; local hi = math.min(rm, rate+sb)
            local pp = math.max(0, hi-sb+1)/N; return (p1 + pp*(f+1)/256)*100
          end
          local list = {}
          for _, id in ipairs({ "POKE_BALL","GREAT_BALL","ULTRA_BALL","SAFARI_BALL","MASTER_BALL" }) do
            local qty = (save.inventory and save.inventory[id]) or 0; local d = def(id)
            if d and qty > 0 then local it = dItem[id]; list[#list+1] = { name = (it and it.name) or id, pct = odds(d), qty = qty } end
          end
          if #list == 0 then local d = def("POKE_BALL"); if d then local it = dItem["POKE_BALL"]; list[1] = { name = (it and it.name) or "POKE_BALL", pct = odds(d), qty = 0 } end end
          return (#list > 0) and list or nil
        end)
        if okc then catch = res end
      end
      battleBlock = { kind = battle.kind, trainer = battle.trainer and battle.trainer.name or nil,
        enemy = brief(eMon), active = brief(pMon), matchup = matchup, catch = catch }
    end

    -- Items: Balls + Healing (for the right-column items panel), in bag order.
    local balls, heals, seen = {}, {}, {}
    local function addItem(id)
      local qty = save.inventory[id]; if not qty or qty <= 0 then return end
      local nm = (dItem[id] and dItem[id].name) or id
      if isBallItem(id) then balls[#balls + 1] = { name = nm, qty = qty }
      elseif isHealItem(id) then heals[#heals + 1] = { name = nm, qty = qty } end
    end
    local ord = save.bagOrder
    if ord then for _, id in ipairs(ord) do if save.inventory[id] and not seen[id] then seen[id] = true; addItem(id) end end end
    for id in pairs(save.inventory or {}) do if not seen[id] then seen[id] = true; addItem(id) end end

    return { active = true, party = party, trainer = trainer, route = route,
      battle = battleBlock, items = { balls = balls, heals = heals } }
  end

  -- ---------------------------------------------------------------------
  -- Per-frame: throttled save read + HP animation easing
  -- ---------------------------------------------------------------------
  local function easeHP(key, target, dt)
    local cur = C.dispHP[key]
    if cur == nil then cur = target end
    cur = cur + (target - cur) * math.min(1, (dt or 0) * 7)
    if math.abs(cur - target) < 0.5 then cur = target end
    C.dispHP[key] = cur
    return cur
  end

  C.onFrame = function(dt)
    C.acc = (C.acc or 0) + (dt or 0)
    if not C.state or C.acc >= INTERVAL then
      C.acc = 0
      local ok, st = pcall(buildState)
      if ok then C.state = st
      elseif st ~= C.buildErr then C.buildErr = st; mod.log:error("kanto_ingame build: %s", tostring(st)) end
    end
    -- advance HP eases toward the freshest values every frame
    local st = C.state
    if st then
      for i = 1, 6 do
        local m = st.party and st.party[i]
        local key = "p" .. i
        if m then
          if C.dispSp[key] ~= m.species then C.dispSp[key] = m.species; C.dispHP[key] = m.hp end
          easeHP(key, m.hp or 0, dt or 0)
        else C.dispHP[key] = nil; C.dispSp[key] = nil end
      end
      local en = st.battle and st.battle.enemy
      if en then
        if C.dispSp.enemy ~= en.species then C.dispSp.enemy = en.species; C.dispHP.enemy = en.hp end
        easeHP("enemy", en.hp or 0, dt or 0)
      else C.dispHP.enemy = nil; C.dispSp.enemy = nil end
    end
    C.updateStickCursor(dt)
  end

  -- ---------------------------------------------------------------------
  -- Draw helpers (all inputs in DESIGN units; multiplied by C.s)
  -- ---------------------------------------------------------------------
  local s = 1
  -- Offscreen canvas the overlay is rendered to when it needs to be dimmed
  -- (see C.drawOverlay) -- cached and only rebuilt if the window size changes.
  local overlayCanvas
  -- LÖVE's built-in Vera font lacks these glyphs (they'd draw a missing-glyph
  -- box), so swap them for safe equivalents before printing. ♀/♂ come straight
  -- from Nidoran's name; the rest are battle-panel decorations.
  local SUB = {
    ["\226\153\128"] = " (F)",  -- ♀ U+2640
    ["\226\153\130"] = " (M)",  -- ♂ U+2642
    ["\226\152\133"] = "*",    -- ★ U+2605 (STAB)
    ["\226\154\160"] = "!",    -- ⚠ U+26A0 (threat)
    ["\226\150\186"] = ">",    -- ► U+25BA (you first)
    ["\226\151\132"] = "<",    -- ◄ U+25C4 (enemy first)
    ["\226\151\134"] = "*",    -- ◆ U+25C6 (badge earned)
    ["\226\151\135"] = "·",    -- ◇ U+25C7 (badge not earned)
  }
  local function sanitize(str)
    if type(str) ~= "string" then str = tostring(str) end
    for k, v in pairs(SUB) do str = str:gsub(k, v) end
    return str
  end
  local function setc(c, a) love.graphics.setColor(c[1], c[2], c[3], a or 1) end
  local function rrect(mode, x, y, w, h, r)
    love.graphics.rectangle(mode, math.floor(x*s), math.floor(y*s), math.floor(w*s), math.floor(h*s),
      (r or 0)*s, (r or 0)*s)
  end
  local function txt(str, x, y, size, col, align, a)
    str = sanitize(str)
    local f = getFont(size*s); love.graphics.setFont(f); setc(col or COL.text, a)
    local X = x*s
    if align == "right" then X = X - f:getWidth(str)
    elseif align == "center" then X = X - f:getWidth(str)/2 end
    love.graphics.print(str, math.floor(X), math.floor(y*s))
  end
  local function textW(str, size) return getFont(size*s):getWidth(str) / s end
  -- break `str` into lines that each fit within `maxW` (design units) at
  -- font `size`, wrapping on spaces; a single word wider than maxW is left
  -- on its own line rather than split mid-word.
  local function wrapText(str, size, maxW)
    local lines, line = {}, ""
    for word in str:gmatch("%S+") do
      local cand = line == "" and word or (line .. " " .. word)
      if textW(cand, size) <= maxW then
        line = cand
      else
        if line ~= "" then lines[#lines+1] = line end
        line = word
      end
    end
    if line ~= "" then lines[#lines+1] = line end
    return lines
  end
  -- shrink a string with ".." until it fits maxW (design units)
  local function ellipsize(str, size, maxW)
    if textW(str, size) <= maxW then return str end
    local s2 = str
    while #s2 > 1 and textW(s2 .. "..", size) > maxW do s2 = s2:sub(1, #s2 - 1) end
    return s2 .. ".."
  end
  local function panel(x, y, w, h, activeGold)
    setc(COL.panel, 0.98); rrect("fill", x, y, w, h, 14)
    love.graphics.setLineWidth(math.max(1, s))
    if activeGold then setc(COL.gold, 0.9) else setc(COL.border, 0.12) end
    rrect("line", x, y, w, h, 14)
  end
  local function bar(x, y, w, h, frac, col)
    setc(COL.barbg, 0.15); rrect("fill", x, y, w, h, h/2)
    if frac and frac > 0 then setc(col, 1); rrect("fill", x, y, w*math.min(1,frac), h, h/2) end
  end
  local function hpCol(f) return f > 0.5 and COL.hi or (f > 0.2 and COL.mid or COL.lo) end
  local function chip(x, y, label, col)
    local w = textW(label, 11) + 12
    setc(col, 1); rrect("fill", x, y, w, 17, 5)
    txt(label, x + 6, y + 2, 11, COL.text)
    return w + 5
  end
  local function money(n) local s2 = tostring(math.floor(n or 0)); local o = s2:reverse():gsub("(%d%d%d)","%1,"):reverse():gsub("^,",""); return "¥"..o end
  local function fmtTime(sec) sec = sec or 0; return string.format("%d:%02d", math.floor(sec/3600), math.floor(sec/60)%60) end
  local function pct(p) if p == nil then return "—" end; if p >= 100 then return "100%" end; if p < 1 then return (p < 0.1 and "<0.1%") or (string.format("%.1f%%", p)) end; return math.floor(p+0.5).."%" end
  local EFFLBL = { [0]="×0", [2]="×¼", [5]="×½", [10]="×1", [20]="×2", [40]="×4" }
  local function effText(m) return EFFLBL[m] or ("×"..(m/10)) end

  -- ---------------------------------------------------------------------
  -- Panel renderers. Each returns the height it drew (design units).
  -- ---------------------------------------------------------------------
  local COLW = 468        -- side column width (design units)
  local PAD = 16

  -- Party rows are BOXLESS (thin dividers between mons). Two styles toggled
  -- with F7: 1 = full (types, HP, XP, moves), 2 = compact (no moves, tighter).
  local function moveRows(m) return math.ceil(math.max(1, #(m.moves or {})) / 2) end
  local function measureMon(m, style)
    if style == 2 then return 54 end
    local hasTypes = m.types and #m.types > 0
    local hasXP = m.xpProgress ~= nil
    local bodyH = 30 + (hasTypes and 22 or 0) + 36 + (hasXP and 32 or 0) + 6 + moveRows(m)*20
    return math.max(72, bodyH)
  end

  local function drawMonRow(m, x, y, w, key, style)
    local rowH = measureMon(m, style)
    local dispHp = C.dispHP[key] or m.hp or 0
    local frac = math.max(0, math.min(1, dispHp / (m.maxhp or 1)))
    local sp = (style == 2) and 52 or 72
    local bodyX = sp + 14
    local bodyW = w - bodyX

    local img = getSprite(m.species, C.dPoke)
    if img then
      local iw, ih = img:getDimensions(); local sc = (sp / math.max(iw, ih)) * s
      setc(COL.text, dispHp <= 0 and 0.5 or 1)
      love.graphics.draw(img, math.floor(x*s), math.floor((y + (rowH-sp)/2)*s), 0, sc, sc)
    end
    if style == 2 then
      -- COMPACT: name + types + Lv on one line, HP bar w/ inline number, thin XP
      local cy = y + 2
      txt(m.name, x + bodyX, cy, 20, COL.text)
      local tx = x + bodyX + textW(m.name, 20) + 8
      if m.types then for _, t in ipairs(m.types) do tx = tx + chip(tx, cy + 1, t, TYPE[t] or COL.dim) end end
      if m.status and m.status ~= "OK" then tx = tx + chip(tx, cy + 1, m.status, COL.lo) end
      txt("Lv " .. (m.level or "?"), x + w, cy + 2, 15, COL.dim, "right")
      cy = cy + 24
      local numStr = string.format("%d/%d", math.floor(dispHp + 0.5), m.maxhp or 0)
      local numW = textW(numStr, 15) + 10
      bar(x + bodyX, cy + 2, bodyW - numW, 10, frac, hpCol(frac))
      txt(numStr, x + w, cy, 15, COL.text, "right", 0.9)
      cy = cy + 18
      if m.xpProgress ~= nil then bar(x + bodyX, cy, bodyW, 6, m.xpProgress, COL.xp) end
      return rowH
    end

    -- FULL
    local cy = y
    txt(m.name, x + bodyX, cy, 24, COL.text)
    txt("Lv " .. (m.level or "?"), x + w, cy + 4, 16, COL.dim, "right")
    local cx = x + bodyX + textW(m.name, 24) + 8
    if m.active then
      local ow = textW("OUT", 12)
      setc(COL.gold, 1); rrect("fill", cx, cy + 2, ow + 12, 18, 5)
      txt("OUT", cx + 6, cy + 3, 12, {0.1, 0.08, 0})
      cx = cx + ow + 20
    end
    if m.status and m.status ~= "OK" then chip(cx, cy + 2, m.status, COL.lo) end
    cy = cy + 30
    if m.types and #m.types > 0 then
      local tx = x + bodyX; for _, t in ipairs(m.types) do tx = tx + chip(tx, cy, t, TYPE[t] or COL.dim) end
      cy = cy + 22
    end
    bar(x + bodyX, cy, bodyW, 12, frac, hpCol(frac)); cy = cy + 16
    txt(string.format("%d / %d HP", math.floor(dispHp + 0.5), m.maxhp or 0), x + bodyX, cy, 16, COL.text, nil, 0.9); cy = cy + 20
    if m.xpProgress ~= nil then
      bar(x + bodyX, cy, bodyW, 8, m.xpProgress, COL.xp); cy = cy + 12
      local lbl = (m.xpToNext and m.xpToNext > 0) and (money(m.xpToNext):gsub("¥","") .. " XP to Lv " .. ((m.level or 0)+1))
        or (((m.exp and money(m.exp):gsub("¥","")) or "0") .. " XP · Max")
      txt(lbl, x + bodyX, cy, 14, COL.dim); cy = cy + 20
    end
    cy = cy + 6
    local colW2 = bodyW / 2
    local mf = 14
    for i, mv in ipairs(m.moves or {}) do
      local col = (i-1) % 2; local row = math.floor((i-1)/2)
      local mx = x + bodyX + col*colW2; local my = cy + row*20
      local pp = (mv.pp ~= nil and mv.maxpp ~= nil) and (mv.pp.."/"..mv.maxpp) or (mv.pp and tostring(mv.pp) or "")
      local ppW = textW(pp, mf)
      txt(ellipsize(mv.name, mf, colW2 - ppW - 12), mx, my, mf, COL.text, nil, 0.92)
      txt(pp, mx + colW2 - 8, my, mf, COL.dim, "right")
    end
    return rowH
  end

  local function party(st, x, y, styleOverride)
    local w = COLW; local style = styleOverride or C.partyStyle or 1
    local list = st.party or {}
    local h = PAD + 34 + 8
    for _, m in ipairs(list) do h = h + measureMon(m, style) + 14 end
    h = h + PAD - 14
    panel(x, y, w, h, false)
    txt("Active Party", x + PAD, y + PAD, 28, COL.text)
    txt((style == 2 and "B" or "A") .. "  ·  " .. #list .. "/6", x + w - PAD, y + PAD + 10, 14, COL.dim, "right")
    local cy = y + PAD + 34 + 8
    for i, m in ipairs(list) do
      local rh = measureMon(m, style)
      if m.active then setc(COL.gold, 0.10); rrect("fill", x + PAD - 6, cy - 6, w - PAD*2 + 12, rh + 12, 8) end
      drawMonRow(m, x + PAD, cy, w - PAD*2, "p" .. i, style)
      cy = cy + rh
      if i < #list then
        setc(COL.border, 0.10); love.graphics.setLineWidth(math.max(1, s))
        love.graphics.line((x+PAD)*s, math.floor((cy+7)*s), (x+w-PAD)*s, math.floor((cy+7)*s))
      end
      cy = cy + 14
    end
    return h
  end

  -- Trainer panel
  local function trainer(st, x, y)
    local t = st.trainer; if not t then return 0 end
    local w = COLW
    local den = t.dexTotal and ("/"..t.dexTotal) or ""
    local rows = {
      { "Money", money(t.money), COL.money }, { "Play Time", fmtTime(t.playTime), COL.text },
      { "Badges", (t.badgeCount or 0).."/"..#(t.badges or {}), COL.text }, { "Party", (t.partyCount or 0).."/6", COL.text },
      { "Pokédex Owned", (t.dexOwned or 0)..den, COL.text }, { "Pokédex Seen", (t.dexSeen or 0)..den, COL.text },
    }
    local badgeRows = math.ceil(#(t.badges or {}) / 4)
    local badgeBoxH, badgeRowPitch = 55, 67   -- box height + gap (was 40 + 12); pitch keeps the same 12px gap
    local h = PAD + 30 + 18 + (math.ceil(#rows/2))*46 + 24 + badgeRows*badgeRowPitch + PAD
    panel(x, y, w, h, false)
    local cy = y + PAD
    txt(t.name ~= "" and t.name or "—", x + PAD, cy, 30, COL.text); cy = cy + 32
    txt((t.version or ""):upper() .. " VERSION", x + PAD, cy, 13, COL.dim); cy = cy + 20
    local colW2 = (w - PAD*2) / 2
    for i, r in ipairs(rows) do
      local col = (i-1)%2; local row = math.floor((i-1)/2)
      local rx = x + PAD + col*colW2; local ry = cy + row*46
      txt(r[1]:upper(), rx, ry, 12, COL.dim)
      txt(r[2], rx, ry + 16, 24, r[3])
    end
    cy = cy + math.ceil(#rows/2)*46 + 8
    txt("GYM BADGES", x + PAD, cy, 12, COL.dim); cy = cy + 20
    local sheet = badgeSheet()
    local bw = (w - PAD*2 - 3*8) / 4
    for i, b in ipairs(t.badges or {}) do
      local col = (i-1)%4; local row = math.floor((i-1)/4)
      local bx = x + PAD + col*(bw+8); local by = cy + row*badgeRowPitch
      setc(b.owned and COL.xp or COL.border, b.owned and 0.22 or 0.05); rrect("fill", bx, by, bw, badgeBoxH, 8)
      local q = sheet and b.owned and sheet.quads[i-1]
      if q then
        local size = 22; local sc = (size/16)*s; setc(COL.text, 1)
        love.graphics.draw(sheet.img, q, math.floor((bx + bw/2 - size/2)*s), math.floor((by + 9)*s), 0, sc, sc)
      else
        txt(b.owned and "◆" or "◇", bx + bw/2, by + 11, 15, b.owned and COL.gold or COL.dim, "center")
      end
      txt(b.name, bx + bw/2, by + 34, 11, b.owned and COL.text or COL.dim, "center")
    end
    return h
  end

  -- Route panel
  local function drawEncSection(title, tab, x, y, w, col)
    if not tab or not tab.species or #tab.species == 0 then return 0 end
    local cy = y
    txt(title .. " · " .. tab.rate .. "% / step", x, cy, 13, COL.dim); cy = cy + 22
    for _, sp in ipairs(tab.species) do
      local img = getSprite(sp.species, C.dPoke)
      if img then local iw, ih = img:getDimensions(); local sc = (36/math.max(iw,ih))*s
        setc(COL.text, 1); love.graphics.draw(img, math.floor(x*s), math.floor((cy-4)*s), 0, sc, sc) end
      txt(sp.name, x + 44, cy, 18, COL.text)
      local lv = (sp.minLevel == sp.maxLevel) and ("Lv "..sp.minLevel) or ("Lv "..sp.minLevel.."-"..sp.maxLevel)
      txt(lv, x + w - 60, cy, 15, COL.dim, "right")
      txt(sp.pct .. "%", x + w, cy, 18, COL.text, "right")
      bar(x + 44, cy + 24, w - 44, 5, sp.pct/100, col); cy = cy + 36
    end
    return cy - y
  end
  local function route(st, x, y)
    local r = st.route; if not r then return 0 end
    local w = COLW
    -- measure
    local function secH(tab) if not tab or not tab.species or #tab.species==0 then return 0 end return 22 + #tab.species*36 end
    local h = PAD + 30 + secH(r.grass) + (r.grass and 10 or 0) + secH(r.water) + PAD
    if not r.grass and not r.water then h = PAD + 30 + 24 + PAD end
    panel(x, y, w, h, false)
    local cy = y + PAD
    txt(r.name, x + PAD, cy, 26, COL.text); cy = cy + 34
    local used = 0
    used = drawEncSection("Grass", r.grass, x + PAD, cy, w - PAD*2, COL.hi)
    cy = cy + used + (used > 0 and 10 or 0)
    used = drawEncSection("Surfing", r.water, x + PAD, cy, w - PAD*2, COL.xp)
    if not r.grass and not r.water then txt("No wild encounters here", x + PAD, cy, 16, COL.dim, nil, 0.6) end
    return h
  end

  -- Battle panel
  local function battle(st, x, y)
    local b = st.battle; if not b then return 0 end
    local w = COLW; local en = b.enemy or {}; local m = b.matchup or {}
    local nMoves = #(m.myMoves or {}); local nThreat = math.max(1, #(m.threats or {}))
    local nCatch = b.catch and #b.catch or 0
    local h = PAD + 20 + 66 + 40 + 22 + (nMoves*26) + 30 + (nThreat*26) + (nCatch > 0 and (30 + nCatch*26) or 0) + PAD
    panel(x, y, w, h, false)
    local cy = y + PAD
    local title = b.kind == "trainer" and (b.trainer and (b.trainer.."'s Pokémon") or "Trainer Battle") or "Wild Battle"
    txt(title:upper(), x + PAD, cy, 13, COL.dim); cy = cy + 20
    -- enemy
    local img = getSprite(en.species, C.dPoke)
    if img then local iw, ih = img:getDimensions(); local sc = (60/math.max(iw,ih))*s
      setc(COL.text,1); love.graphics.draw(img, math.floor((x+PAD)*s), math.floor(cy*s), 0, sc, sc) end
    txt(en.name or "?", x + PAD + 72, cy, 24, COL.text)
    txt("Lv " .. (en.level or "?"), x + PAD + 72 + textW(en.name or "?", 24) + 10, cy + 6, 16, COL.dim)
    local tx = x + PAD + 72
    for _, t in ipairs(en.types or {}) do tx = tx + chip(tx, cy + 30, t, TYPE[t] or COL.dim) end
    cy = cy + 66
    local eh = C.dispHP.enemy or en.hp or 0
    local ef = math.max(0, math.min(1, eh / (en.maxhp or 1)))
    bar(x + PAD, cy, w - PAD*2, 12, ef, hpCol(ef)); cy = cy + 16
    txt(string.format("%d / %d HP", math.floor(eh+0.5), en.maxhp or 0), x + PAD, cy, 16, COL.text, nil, 0.9); cy = cy + 24
    if m.speed and m.speed.faster then
      local sp = m.speed.faster == "you" and "► You move first" or (m.speed.faster == "them" and "◄ Enemy moves first" or "= Speed tie")
      txt(sp, x + PAD, cy, 16, COL.gold);
    end
    cy = cy + 22
    txt("YOUR MOVES", x + PAD, cy, 13, COL.dim); cy = cy + 22
    do
      local myMoves = m.myMoves or {}
      -- Size the right-hand stat column from what this battle's moves
      -- actually need, instead of a fixed 120px gap: a wide "120 pow ·
      -- 40/40" (or "STATUS 30/30") string would previously run right into
      -- the effectiveness multiplier next to it. Measuring first guarantees
      -- the two never collide, however long the numbers get.
      local powW = 0
      for _, mv in ipairs(myMoves) do
        local powStr = mv.status
          and ("STATUS " .. (mv.pp or "?") .. "/" .. (mv.maxpp or "?"))
          or ((mv.power and (mv.power.." pow") or "—") .. " · " .. (mv.pp or "?") .. "/" .. (mv.maxpp or "?"))
        powW = math.max(powW, textW(powStr, 13))
      end
      local powX = x + w - PAD
      local effX = powX - powW - 14
      for _, mv in ipairs(myMoves) do
        if mv.best then setc(COL.hi, 0.12); rrect("fill", x + PAD - 6, cy - 2, w - PAD*2 + 12, 24, 6) end
        local cx = x + PAD
        cx = cx + chip(cx, cy + 1, mv.type, TYPE[mv.type] or COL.dim)
        local nameStr = mv.name .. (mv.stab and " ★" or "")
        txt(ellipsize(nameStr, 16, effX - 14 - cx), cx, cy, 16, COL.text)
        if mv.status then
          txt("STATUS " .. (mv.pp or "?") .. "/" .. (mv.maxpp or "?"), powX, cy, 13, COL.dim, "right")
        else
          local tier = mv.mult == 0 and COL.lo or (mv.mult > 10 and COL.super or (mv.mult == 10 and COL.dim or COL.resist))
          txt(effText(mv.mult), effX, cy, 16, tier, "right")
          txt((mv.power and (mv.power.." pow") or "—") .. " · " .. (mv.pp or "?") .. "/" .. (mv.maxpp or "?"), powX, cy, 13, COL.dim, "right")
        end
        cy = cy + 26
      end
    end
    cy = cy + 6
    txt("THREATS", x + PAD, cy, 13, COL.dim); cy = cy + 22
    if m.threats and #m.threats > 0 then
      for _, t in ipairs(m.threats) do
        local cx = x + PAD; setc(COL.threat, 1)
        txt("⚠", cx, cy, 16, COL.threat); cx = cx + 22
        cx = cx + chip(cx, cy + 1, t.type, TYPE[t.type] or COL.dim)
        txt(ellipsize(t.name .. "  " .. effText(t.mult), 16, x + w - PAD - cx), cx, cy, 16, COL.threat)
        cy = cy + 26
      end
    else
      txt("No super-effective moves from its set.", x + PAD, cy, 15, COL.dim, nil, 0.6); cy = cy + 26
    end
    if nCatch > 0 then
      cy = cy + 4; txt("CATCH ODDS", x + PAD, cy, 13, COL.dim); cy = cy + 22
      for _, c in ipairs(b.catch) do
        local a = c.qty > 0 and 1 or 0.45
        local pctStr = pct(c.pct)
        local pctW = textW(pctStr, 16) + 10
        local nameStr = c.name .. (c.qty > 0 and (" ×"..c.qty) or " (none)")
        txt(ellipsize(nameStr, 16, w - PAD*2 - pctW), x + PAD, cy, 16, COL.text, nil, a)
        local pcol = c.pct >= 60 and COL.hi or (c.pct >= 25 and COL.mid or COL.resist)
        txt(pctStr, x + w - PAD, cy, 16, pcol, "right", a)
        cy = cy + 26
      end
    end
    return h
  end

  -- Items panel: two fixed columns (Balls | Healing), capped with "+N more".
  local ITEM_CAP = 6
  local function items(st, x, y)
    local it = st.items
    if not it or (#it.balls == 0 and #it.heals == 0) then return 0 end
    local w = COLW; local colGap = 18
    local cw = (w - PAD*2 - colGap) / 2
    local nB = math.min(ITEM_CAP, #it.balls); local nH = math.min(ITEM_CAP, #it.heals)
    local moreB, moreH = #it.balls - nB, #it.heals - nH
    local rows = math.max(nB, nH, 1)
    local extra = (moreB > 0 or moreH > 0) and 18 or 0
    local h = PAD + 34 + 22 + rows*22 + extra + PAD
    panel(x, y, w, h, false)
    txt("Items", x + PAD, y + PAD, 26, COL.text)
    local lcx = x + PAD; local rcx = x + PAD + cw + colGap
    local hy = y + PAD + 34
    txt("BALLS", lcx, hy, 13, COL.dim)
    txt("HEALING", rcx, hy, 13, COL.dim)
    local cy0 = hy + 22
    for i = 1, nB do local b = it.balls[i]; local ry = cy0 + (i-1)*22
      txt(b.name, lcx, ry, 16, COL.text); txt("×" .. b.qty, lcx + cw, ry, 16, COL.dim, "right") end
    for i = 1, nH do local hh = it.heals[i]; local ry = cy0 + (i-1)*22
      txt(hh.name, rcx, ry, 16, COL.text); txt("×" .. hh.qty, rcx + cw, ry, 16, COL.dim, "right") end
    if #it.balls == 0 then txt("—", lcx, cy0, 16, COL.dim, nil, 0.5) end
    if #it.heals == 0 then txt("—", rcx, cy0, 16, COL.dim, nil, 0.5) end
    if moreB > 0 then txt("+" .. moreB .. " more", lcx, cy0 + nB*22, 12, COL.dim, nil, 0.7) end
    if moreH > 0 then txt("+" .. moreH .. " more", rcx, cy0 + nH*22, 12, COL.dim, nil, 0.7) end
    return h
  end

  -- =====================================================================
  -- Interactive management screens (i = items, p = party/boxes).
  -- Mouse-driven: click to pick up, click a highlighted target to drop.
  -- A lightweight state is pushed onto game.stack so the engine routes ALL
  -- keys to it (Game:keypressed -> top.onKeyPressed) and freezes the world
  -- (stack:update only ticks the top). We draw in raw window coords here.
  -- Milestone 1: open/close/freeze/cursor/capture + read-only panels + hover.
  -- =====================================================================
  if C.screen == nil then C.screen = false end   -- false | "items" | "party"
  C.held    = C.held or nil        -- what the cursor is carrying (later milestones)
  C.boxView = C.boxView or nil     -- which box is shown on the right
  C.hit     = C.hit or {}          -- clickable regions recorded each draw
  C.status  = C.status or nil      -- transient footer message
  C.mx, C.my = C.mx or 0, C.my or 0
  C.iv      = C.iv or nil           -- item view order: { bag={ids}, pc={ids} }
  C.isort   = C.isort or { bag = { mode = "custom", dir = 1 }, pc = { mode = "custom", dir = 1 } }
  C.iscroll = C.iscroll or { bag = 0, pc = 0 }
  C.iFocus  = C.iFocus or "bag"      -- which side (bag/pc) D-pad up/down scrolls, controller-only
  C.iCursor = C.iCursor or { bag = 1, pc = 1 }  -- D-pad row highlight per side, controller-only
  C.iLayout = C.iLayout or {}        -- per-side panel geometry, for drop hit-testing
  C.savedFlash = C.savedFlash or {}  -- per-side "Saved!" flash timestamps
  C.pLayout = C.pLayout or {}        -- party/box slot + rail geometry, for drop hit-testing

  -- item categories (same buckets as the Pocket PC app) -> a colour swatch
  local HEAL_IDS = {
    POTION=1,SUPER_POTION=1,HYPER_POTION=1,MAX_POTION=1,FULL_RESTORE=1,FULL_HEAL=1,ANTIDOTE=1,
    BURN_HEAL=1,ICE_HEAL=1,AWAKENING=1,PARLYZ_HEAL=1,REVIVE=1,MAX_REVIVE=1,ETHER=1,MAX_ETHER=1,
    ELIXER=1,MAX_ELIXER=1,FRESH_WATER=1,SODA_POP=1,LEMONADE=1,
  }
  local BATTLE_IDS = { X_ATTACK=1,X_DEFEND=1,X_SPEED=1,X_SPECIAL=1,X_ACCURACY=1,DIRE_HIT=1,GUARD_SPEC=1,POKE_DOLL=1 }
  local KEY_IDS = { BICYCLE=1,TOWN_MAP=1,ITEMFINDER=1,OLD_ROD=1,GOOD_ROD=1,SUPER_ROD=1,S_S_TICKET=1,
    BIKE_VOUCHER=1,GOLD_TEETH=1,CARD_KEY=1,LIFT_KEY=1,SILPH_SCOPE=1,POKE_FLUTE=1,OAKS_PARCEL=1,
    SECRET_KEY=1,EXP_ALL=1,COIN_CASE=1,DOME_FOSSIL=1,HELIX_FOSSIL=1,OLD_AMBER=1 }
  local function itemCat(id, def)
    if (def and def.ball) or id:find("BALL", 1, true) then return "BALLS" end
    if (def and def.machine) or id:match("^TM") or id:match("^HM") then return "TM" end
    if HEAL_IDS[id] or id:find("POTION",1,true) or id:find("HEAL",1,true) or id:find("REVIVE",1,true)
      or id:find("RESTORE",1,true) or id:find("ETHER",1,true) or id:find("ELIXER",1,true) then return "HEALING" end
    if BATTLE_IDS[id] then return "BATTLE" end
    if KEY_IDS[id] or (def and def.keyItem) or (def and def.tossable == false) then return "KEY" end
    return "OTHER"
  end
  local CATCOL = {
    BALLS = hex("e05a5a"), HEALING = hex("7dd87d"), BATTLE = hex("e0b330"),
    KEY = hex("7a8fe0"), TM = hex("b06fd0"), OTHER = hex("9a9a80"),
  }
  local CATORD = { BALLS = 1, HEALING = 2, BATTLE = 3, TM = 4, OTHER = 5, KEY = 6 }
  local PC_ITEM_CAP = 50

  local function itemName(id)
    local d = C.game and C.game.data and C.game.data.items and C.game.data.items[id]
    return (d and d.name) or tostring(id)
  end
  local function monMax(mon, def)
    if mon.stats and mon.stats.hp then return mon.stats.hp end
    if C.Stats and def and def.baseStats then
      local ok, st = pcall(C.Stats.calc, def, mon.level or 1, mon.dvs or {}, mon.statExp)
      if ok and st then return st.hp end
    end
    return mon.hp or 1
  end
  local function bagList()
    local save = C.game and C.game.save; if not save then return {} end
    local inv, order = save.inventory or {}, save.bagOrder
    local list, seen = {}, {}
    local function add(id)
      if inv[id] and inv[id] > 0 and not seen[id]
        and not (C.Bag and C.Bag.isBadge and C.Bag.isBadge(id)) then
        seen[id] = true; list[#list+1] = { id = id, name = itemName(id), qty = inv[id] }
      end
    end
    if order then for _, id in ipairs(order) do add(id) end end
    for id in pairs(inv) do add(id) end
    return list
  end
  local function pcItemList()
    local save = C.game and C.game.save; if not save then return {} end
    local pc, order = save.pcItems or {}, save.pcOrder
    local list, seen = {}, {}
    local function add(id)
      if pc[id] and pc[id] > 0 and not seen[id] then
        seen[id] = true; list[#list+1] = { id = id, name = itemName(id), qty = pc[id] }
      end
    end
    if order then for _, id in ipairs(order) do add(id) end end
    for id in pairs(pc) do add(id) end
    return list
  end

  -- record a clickable region (design units) + report hover
  local function region(x, y, w, h, tag, data)
    C.hit[#C.hit+1] = { x = x, y = y, w = w, h = h, tag = tag, data = data }
    return C.mx >= x and C.mx <= x+w and C.my >= y and C.my <= y+h
  end
  local function listPanel(px, py, pw, ph, title, sub, rows, sideTag)
    panel(px, py, pw, ph, false)
    txt(title, px+PAD, py+14, 22, COL.text)
    if sub then txt(sub, px+pw-PAD, py+18, 15, COL.dim, "right") end
    local ry, rh = py+56, 40
    local maxRows = math.max(1, math.floor((ph - 70) / rh))
    for i = 1, math.min(#rows, maxRows) do
      local r = rows[i]; local y = ry + (i-1)*rh
      local hov = region(px+8, y, pw-16, rh-4, sideTag, i)
      if hov then setc(COL.gold, 0.13); rrect("fill", px+8, y, pw-16, rh-4, 8) end
      txt(ellipsize(r.name, 18, pw - PAD*2 - 70), px+PAD, y+5, 18, COL.text)
      if r.right then txt(r.right, px+pw-PAD, y+6, 15, COL.dim, "right") end
    end
    if #rows == 0 then txt("- empty -", px+PAD, ry, 16, COL.dim, nil, 0.6) end
    if #rows > maxRows then txt("+"..(#rows-maxRows).." more", px+PAD, py+ph-26, 13, COL.dim) end
  end

  local function invOf(side)
    local save = C.game and C.game.save; if not save then return {} end
    return side == "bag" and (save.inventory or {}) or (save.pcItems or {})
  end
  local function isBadgeItem(id) return C.Bag and C.Bag.isBadge and C.Bag.isBadge(id) end
  local function buildItemView()
    C.iv = { bag = {}, pc = {} }
    for _, r in ipairs(bagList()) do C.iv.bag[#C.iv.bag+1] = r.id end
    -- the in-game PC always shows items A-Z, so open the PC view that way to match
    local pcRows = pcItemList()
    table.sort(pcRows, function(a, b) return a.name < b.name end)
    for _, r in ipairs(pcRows) do C.iv.pc[#C.iv.pc+1] = r.id end
    C.isort.pc = { mode = "name", dir = 1 }
  end
  local function itemRows(side)
    if not C.iv then buildItemView() end
    local inv, seen, rows = invOf(side), {}, {}
    for _, id in ipairs(C.iv[side] or {}) do
      if inv[id] and inv[id] > 0 and not seen[id] and not (side == "bag" and isBadgeItem(id)) then
        seen[id] = true
        rows[#rows+1] = { id = id, name = itemName(id), qty = inv[id], cat = itemCat(id, C.game.data.items[id]) }
      end
    end
    for id, q in pairs(inv) do   -- newly-acquired items not yet in the view order
      if q > 0 and not seen[id] and not (side == "bag" and isBadgeItem(id)) then
        seen[id] = true; C.iv[side][#C.iv[side]+1] = id
        rows[#rows+1] = { id = id, name = itemName(id), qty = q, cat = itemCat(id, C.game.data.items[id]) }
      end
    end
    return rows
  end
  -- Pixel offset (within the scrollable content, ignoring current scroll) of
  -- row `idx` in `side`'s list, plus its height. Mirrors the disp/header
  -- layout built in itemPanel below, so the D-pad cursor can figure out
  -- where a row will land and scroll it into view before that row is drawn.
  local function itemContentOffset(side, idx)
    local rows = itemRows(side)
    local headH, itemH = 26, 38
    if C.isort[side].mode ~= "type" then return (idx-1)*itemH, itemH end
    local prev, offset = nil, 0
    for i, r in ipairs(rows) do
      if r.cat ~= prev then offset = offset + headH; prev = r.cat end
      if i == idx then return offset, itemH end
      offset = offset + itemH
    end
    return offset, itemH
  end
  local function sortSide(side, mode)
    local st = C.isort[side]
    if st.mode == mode then st.dir = -st.dir else st.dir, st.mode = 1, mode end
    local rows, dir = itemRows(side), st.dir
    table.sort(rows, function(a, b)
      local pa, pb
      if mode == "type" then pa, pb = CATORD[a.cat] or 9, CATORD[b.cat] or 9
      elseif mode == "qty" then pa, pb = a.qty, b.qty
      else pa, pb = a.name, b.name end
      if pa == pb then return a.name < b.name end
      if dir < 0 then return pa > pb else return pa < pb end
    end)
    C.iv[side] = {}; for _, r in ipairs(rows) do C.iv[side][#C.iv[side]+1] = r.id end
    C.status = side == "bag"
      and ("Sorted Bag view by "..mode.."  -  press Save order to keep it in-game")
      or  ("Sorted PC view by "..mode.."  -  browsing only (the in-game PC is always A-Z)")
  end
  local function orderIds(list, inv)
    local out = {}
    for _, id in ipairs(list or {}) do if inv[id] and inv[id] > 0 then out[#out+1] = id end end
    return out
  end
  local function viewIds(side)  return orderIds(C.iv[side], invOf(side)) end
  local function savedIds(side)
    local save = C.game.save
    return orderIds(side == "bag" and save.bagOrder or save.pcOrder, invOf(side))
  end
  local function isDirty(side)
    local a, b = viewIds(side), savedIds(side)
    if #a ~= #b then return true end
    for i = 1, #a do if a[i] ~= b[i] then return true end end
    return false
  end
  local function applyOrder(side)
    local order = viewIds(side)
    if side == "bag" then C.game.save.bagOrder = order else C.game.save.pcOrder = order end
    C.savedFlash[side] = love.timer.getTime()
    C.status = "Saved this order to your in-game "..(side=="bag" and "Bag" or "PC")
  end
  -- insert `id` before `beforeId` (or append if nil/not found)
  local function insertBefore(v, id, beforeId)
    if beforeId and beforeId ~= id then
      for i, vid in ipairs(v) do if vid == beforeId then table.insert(v, i, id); return end end
    end
    v[#v+1] = id
  end
  local function reorderView(side, id, beforeId)
    if beforeId == id then return end   -- dropping "before itself" is a no-op
    local v = C.iv[side]
    for i, vid in ipairs(v) do if vid == id then table.remove(v, i); break end end
    insertBefore(v, id, beforeId)
  end
  local function doTransfer(fromSide, id, qty, toSide, beforeId)
    local save = C.game.save
    qty = math.max(1, math.floor(qty or 1))
    if fromSide == toSide then reorderView(fromSide, id, beforeId); return true end
    if fromSide == "bag" then
      local inv = save.inventory or {}
      qty = math.min(qty, inv[id] or 0)
      if qty <= 0 then return false, "Nothing to move" end
      local pc = save.pcItems or {}; save.pcItems = pc
      if not pc[id] then local n=0; for _ in pairs(pc) do n=n+1 end
        if n >= PC_ITEM_CAP then return false, "PC is full" end end
      C.Bag.remove(save, id, qty); pc[id] = (pc[id] or 0) + qty
    else
      local pc = save.pcItems or {}
      qty = math.min(qty, pc[id] or 0)
      if qty <= 0 then return false, "Nothing to move" end
      if not C.Bag.add(save, id, qty) then return false, "Bag can't hold more" end
      pc[id] = pc[id] - qty; if pc[id] <= 0 then pc[id] = nil end
    end
    if not (invOf(fromSide)[id] and invOf(fromSide)[id] > 0) then
      for i, vid in ipairs(C.iv[fromSide]) do if vid == id then table.remove(C.iv[fromSide], i); break end end
    end
    local inDest = false
    for _, vid in ipairs(C.iv[toSide]) do if vid == id then inDest = true; break end end
    if not inDest then insertBefore(C.iv[toSide], id, beforeId) end
    return true
  end
  -- resolve a cursor position to { side, beforeId } from the recorded row geometry
  local function dropTarget(dx, dy)
    for _, side in ipairs({ "bag", "pc" }) do
      local L = C.iLayout[side]
      if L and dx >= L.x and dx <= L.x+L.w and dy >= L.y-30 and dy <= L.y+L.h+40 then
        for _, it in ipairs(L.items or {}) do
          if dy < it.y + it.h/2 then return side, it.id end
        end
        return side, nil   -- past the last row -> append
      end
    end
    return nil
  end
  -- why a drop onto `toSide` would be refused (nil = it's fine). Mirrors doTransfer.
  local function dropBlockedReason(fromSide, id, qty, toSide)
    if fromSide == toSide then return nil end     -- same-side reorder is always ok
    local save = C.game.save
    if toSide == "pc" then
      local pc = save.pcItems or {}
      if not pc[id] then
        local n = 0; for _ in pairs(pc) do n = n + 1 end
        if n >= PC_ITEM_CAP then return "PC is full" end
      end
    else
      local inv = save.inventory or {}
      local slots = (C.Bag and C.Bag.slots and C.Bag.slots(save)) or 0
      if not inv[id] and slots >= ((C.Bag and C.Bag.CAPACITY) or 20) then return "Bag is full" end
      if (inv[id] or 0) + (qty or 1) > 99 then return "Stack maxed (99)" end
    end
    return nil
  end

  local SORTS = { {"type","Type"}, {"name","A-Z"}, {"qty","Qty"} }
  local function triangle(cx, cy, up)
    local d = 4
    if up then love.graphics.polygon("fill", cx*s, (cy-d)*s, (cx-d)*s, (cy+d)*s, (cx+d)*s, (cy+d)*s)
    else       love.graphics.polygon("fill", (cx-d)*s, (cy-d)*s, (cx+d)*s, (cy-d)*s, cx*s, (cy+d)*s) end
  end
  local function itemPanel(side, px, py, pw, ph)
    local rows = itemRows(side)
    local padHeld = C.held and C.held.pad
    -- Normally the cursor can only sit ON a row. While this side is focused
    -- during a pad pickup -- source side included, now that the D-pad can
    -- reorder in place as well as transfer -- it can also sit one past the
    -- last row, an "append to the end of the list" slot.
    local isDropSide = padHeld and side == C.iFocus
    local maxCur = isDropSide and (#rows + 1) or #rows
    C.iCursor[side] = maxCur > 0 and math.max(1, math.min(maxCur, C.iCursor[side] or 1)) or 1
    local cap = side == "bag" and ((C.Bag and C.Bag.CAPACITY) or 20) or PC_ITEM_CAP
    -- Where the item would land: the D-pad's focused side for a pad pickup,
    -- otherwise wherever the mouse cursor is (drag / click-then-click).
    local ds = padHeld and C.iFocus or dropTarget(C.mx, C.my)
    local isTarget = C.held and C.held.from ~= side and ds == side
    local blocked = isTarget and dropBlockedReason(C.held.from, C.held.id, C.held.qty, side)
    -- Gold panel border: the D-pad's focused side, before OR during a pad
    -- pickup (so it never disappears once you pick something up), or the
    -- classic "not holding anything" focus for keyboard/mouse users.
    local focused = C.iFocus == side and (padHeld or not C.held)
    panel(px, py, pw, ph, (isTarget and not blocked) or focused)   -- gold glow when droppable, or D-pad focused
    if blocked then
      setc(COL.lo, 0.08); rrect("fill", px, py, pw, ph, 14)
      love.graphics.setLineWidth(math.max(2, 2*s)); setc(COL.lo, 0.85); rrect("line", px, py, pw, ph, 14)
    end
    txt(side == "bag" and "BAG" or "PC ITEMS", px+PAD, py+12, 22, COL.text)
    txt(#rows.."/"..cap.." slots", px+pw-PAD, py+16, 14, #rows>=cap and COL.lo or COL.dim, "right")
    -- controls: Sort [Type][A-Z][Qty]   Save
    local st = C.isort[side]
    local sy, sx = py+46, px+PAD
    txt("Sort", sx, sy+5, 13, COL.dim); sx = sx + textW("Sort", 13) + 8
    for _, m in ipairs(SORTS) do
      local active = st.mode == m[1]
      local bw = textW(m[2], 13) + (active and 30 or 16)
      region(sx, sy, bw, 26, "sort", { side = side, mode = m[1] })
      setc(active and COL.gold or COL.panel, active and 0.92 or 0.6); rrect("fill", sx, sy, bw, 26, 6)
      txt(m[2], sx+8, sy+5, 13, active and COL.panel or COL.dim)
      if active then setc(COL.panel, 1); triangle(sx+bw-12, sy+13, st.dir > 0) end
      sx = sx + bw + 6
    end
    if side == "bag" then  -- Save order: dim when clean, gold when dirty, green flash on save
      local flash = C.savedFlash[side] and (love.timer.getTime() - C.savedFlash[side] < 1.3)
      local dirty = isDirty(side)
      local lbl = flash and "Saved!" or (dirty and "Save order" or "Saved")
      local bw = textW(lbl, 13) + 18
      local bx = px+pw-PAD-bw
      if dirty and not flash then region(bx, sy, bw, 26, "apply", side) end
      local lit = dirty or flash
      setc(flash and COL.hi or (dirty and COL.gold or COL.panel), lit and 0.9 or 0.45); rrect("fill", bx, sy, bw, 26, 6)
      if C.iFocus == "bag" and C.iOnSave and not C.held then
        love.graphics.setLineWidth(math.max(2, 2*s)); setc(COL.gold, 0.95); rrect("line", bx, sy, bw, 26, 6)
      end
      txt(lbl, bx+9, sy+5, 13, lit and COL.panel or COL.dim, nil, lit and 1 or 0.6)
    else  -- PC order can't be saved: the in-game PC always displays A-Z.
      -- On its own line below the sort buttons (not sharing their row) so it
      -- can never run into them, however narrow the panel gets -- e.g. once
      -- the touch nav buttons widen the gap between panels and shrink pw.
      txt("view only - PC is always A-Z in-game", px+pw-PAD, sy+32, 12, COL.dim, "right", 0.7)
    end
    -- build display list (category headers when sorted by Type)
    local grouped = st.mode == "type"
    local disp = {}
    if grouped then
      local counts = {}; for _, r in ipairs(rows) do counts[r.cat] = (counts[r.cat] or 0)+1 end
      local prev
      for _, r in ipairs(rows) do
        if r.cat ~= prev then disp[#disp+1] = { head = true, cat = r.cat, n = counts[r.cat] }; prev = r.cat end
        disp[#disp+1] = { r = r }
      end
    else
      for _, r in ipairs(rows) do disp[#disp+1] = { r = r } end
    end
    local headH, itemH = 26, 38
    -- Extra headroom (was 84) so the PC panel's "view only" note has its own
    -- line below the sort buttons without crowding the item list; applied to
    -- both sides so the two panels' lists still start at the same height.
    local ry = py + 96
    local listH = ph - (ry - py) - 40
    local contentH = 0
    for _, e in ipairs(disp) do contentH = contentH + (e.head and headH or itemH) end
    local maxScroll = math.max(0, contentH - listH)
    C.iscroll[side] = math.max(0, math.min(maxScroll, C.iscroll[side] or 0))
    local scroll = C.iscroll[side]
    local items = {}
    love.graphics.setScissor(math.floor(px*s), math.floor(ry*s), math.ceil(pw*s), math.ceil(listH*s))
    local yy = ry - scroll
    local itemIdx = 0   -- running index into `rows`, skipping headers -- lines up with C.iCursor[side]
    for _, e in ipairs(disp) do
      if e.head then
        if yy + headH > ry and yy < ry + listH then
          setc(CATCOL[e.cat] or CATCOL.OTHER, 0.95); rrect("fill", px+PAD, yy+headH-11, 10, 10, 2)
          local cname = e.cat:sub(1,1) .. e.cat:sub(2):lower()
          txt(cname, px+PAD+16, yy+3, 13, COL.dim)
          txt("("..e.n..")", px+PAD+18+textW(cname, 13), yy+4, 12, COL.dim, nil, 0.65)
          setc(COL.border, 0.09); love.graphics.setLineWidth(math.max(1, s))
          love.graphics.line((px+PAD)*s, (yy+headH-1)*s, (px+pw-PAD)*s, (yy+headH-1)*s)
        end
        yy = yy + headH
      else
        local r = e.r
        itemIdx = itemIdx + 1
        local isCursor = C.iFocus == side and not (side == "bag" and C.iOnSave) and (C.iCursor[side] or 1) == itemIdx
        if yy + itemH > ry and yy < ry + listH then
          local held = C.held and C.held.from == side and C.held.id == r.id
          local hov = region(px+8, yy, pw-16, itemH-3, "itemrow", { side = side, id = r.id })
          local cc = CATCOL[r.cat] or CATCOL.OTHER
          if held then setc(COL.gold, 0.06) elseif hov then setc(cc, 0.16) else setc(cc, 0.06) end
          rrect("fill", px+8, yy, pw-16, itemH-3, 7)
          if isCursor and not held and not isDropSide then
            love.graphics.setLineWidth(math.max(2, 2*s)); setc(COL.gold, 0.9)
            rrect("line", px+8, yy, pw-16, itemH-3, 7)
          end
          setc(cc, held and 0.4 or 1); rrect("fill", px+PAD, yy+itemH/2-7, 12, 12, 3)
          txt(ellipsize(r.name, 17, pw - PAD*3 - 96), px+PAD+22, yy+7, 17, held and COL.dim or COL.text)
          txt("x"..r.qty, px+pw-PAD, yy+8, 16, COL.dim, "right")
        end
        items[#items+1] = { y = yy, h = itemH, id = r.id }
        yy = yy + itemH
      end
    end
    -- insertion line while holding over this side (not when the drop is blocked,
    -- and not on the source side for a pad pickup -- that side no longer drops)
    if C.held and ds == side and not blocked then
      local ly = ry + listH
      if #items == 0 then
        ly = ry   -- nothing here yet: line goes at the top, where the first item will land
      elseif padHeld then
        local it = items[C.iCursor[side] or 0]
        if it then ly = it.y
        else ly = items[#items].y + items[#items].h end
      else
        local _, bId = dropTarget(C.mx, C.my)
        for _, it in ipairs(items) do if it.id == bId then ly = it.y; break end end
      end
      ly = math.max(ry+1, math.min(ly, ry + listH - 1))
      setc(COL.gold, 0.95); love.graphics.setLineWidth(math.max(2, 3*s))
      love.graphics.line((px+PAD)*s, ly*s, (px+pw-PAD-8)*s, ly*s)
    end
    love.graphics.setScissor()
    C.iLayout[side] = { x = px, y = ry, w = pw, h = listH, items = items, contentH = contentH }
    if #rows == 0 then
      txt(C.held and "drop items here" or "No items - drag some here", px+PAD, ry+8, 16, COL.dim, nil, 0.6)
    end
    if maxScroll > 0 then      -- scrollbar
      local tx, tw = px+pw-11, 6
      setc(COL.border, 0.10); rrect("fill", tx, ry, tw, listH, 3)
      local thumbH = math.max(30, listH * (listH / contentH))
      local thumbY = ry + (scroll / maxScroll) * (listH - thumbH)
      setc(COL.dim, 0.7); rrect("fill", tx, thumbY, tw, thumbH, 3)
    end
    bar(px+PAD, py+ph-22, pw-PAD*2, 8, #rows/cap, #rows>=cap and COL.lo or COL.hi)
    if blocked then          -- big "FULL" warning badge over the panel
      local bw = textW(blocked, 22) + 56
      local bx, by = px+pw/2 - bw/2, py + ph*0.42
      setc(COL.lo, 0.95); rrect("fill", bx, by, bw, 46, 12)
      txt(blocked, px+pw/2, by+11, 22, COL.panel, "center")
    end
  end
  local function drawItemsPanels(lx, rx, py, pw, ph)
    itemPanel("bag", lx, py, pw, ph)
    itemPanel("pc",  rx, py, pw, ph)
  end
  local function drawHeldItem()
    local h = C.held; if not h then return end
    local cat = itemCat(h.id, C.game.data.items[h.id])
    local padHeld = h.pad
    if h.mode == "armed" and not padHeld then       -- pulsing arrow toward the other panel (mouse click-then-click flow)
      local toSide = h.from == "bag" and "pc" or "bag"
      local from, to = C.iLayout[h.from], C.iLayout[toSide]
      if from and to then
        local midY = love.graphics.getHeight() / s / 2
        local dirR = (h.from == "bag")
        local x0 = dirR and (from.x+from.w-30) or (from.x+30)
        local x1 = dirR and (to.x+30) or (to.x+to.w-30)
        local pulse = 0.5 + 0.5*math.abs(math.sin(love.timer.getTime()*3.5))
        setc(COL.gold, pulse); love.graphics.setLineWidth(math.max(2, 5*s))
        love.graphics.line(x0*s, midY*s, x1*s, midY*s)
        local hs = dirR and 1 or -1
        love.graphics.polygon("fill", x1*s, midY*s, (x1-hs*26)*s, (midY-16)*s, (x1-hs*26)*s, (midY+16)*s)
        txt("click to move here", (x0+x1)/2, midY-46, 18, COL.gold, "center", pulse)
      end
    end
    local dsz = padHeld and C.iFocus or dropTarget(C.mx, C.my)
    local blk = dsz and dsz ~= h.from and dropBlockedReason(h.from, h.id, h.qty, dsz)
    -- ghost chip: rides the D-pad cursor's row for a pad pickup (so it doesn't
    -- float at a stale mouse position), or the cursor itself for drag/click.
    -- No row at the cursor means it's past the last one -- the "append to
    -- the end" slot -- so anchor near the bottom of the visible list instead.
    local gx, gy = C.mx, C.my
    if padHeld then
      local L = C.iLayout[C.iFocus]
      if L then
        local it = L.items[C.iCursor[C.iFocus] or 0]
        if it then
          gx, gy = L.x + L.w/2 - 30, it.y + it.h/2 - 17
        elseif #L.items > 0 then   -- past the last row: hover over the phantom end-of-list slot
          local last = L.items[#L.items]
          gx, gy = L.x + L.w/2 - 30, last.y + last.h + last.h/2 - 17
        else                       -- side is empty: hover near the top, where the line is
          gx, gy = L.x + L.w/2 - 30, L.y + 2
        end
      end
    end
    local qtyStr = (h.max and h.max > 1) and ("  x"..h.qty) or ""
    local label = itemName(h.id) .. qtyStr
    local w = textW(label, 17) + 46
    setc(COL.panel, 0.97); rrect("fill", gx+16, gy-16, w, 34, 8)
    setc(blk and COL.lo or COL.gold, 0.9); love.graphics.setLineWidth(math.max(1, s)); rrect("line", gx+16, gy-16, w, 34, 8)
    setc(CATCOL[cat] or CATCOL.OTHER, 1); rrect("fill", gx+26, gy-3, 12, 12, 3)
    txt(label, gx+46, gy-9, 17, COL.text)
    if blk then txt(blk, gx+16, gy+22, 13, COL.lo)
    elseif h.max and h.max > 1 then txt(padHeld and "L2/R2 = qty" or "wheel = qty", gx+16, gy+22, 12, COL.gold, nil, 0.85)
    elseif padHeld then txt("A drops here  --  B cancels", gx+16, gy+22, 12, COL.dim, nil, 0.85) end
  end
  -- ===================== Party / Boxes screen =========================
  local NBOX = (C.Boxes and C.Boxes.COUNT) or 12
  local BCAP = (C.Boxes and C.Boxes.CAPACITY) or 20
  local PMAX = (C.Party and C.Party.MAX) or 6
  local function boxesEnsure()
    if C.Boxes then C.Boxes.ensure(C.game.save) end
    return C.game.save.boxes or {}
  end
  local function arrayOf(loc, boxN)
    if loc == "party" then return C.game.save.party or {} end
    return boxesEnsure()[boxN] or {}
  end
  local function targetMonAt(t) return (t and t.index) and arrayOf(t.loc, t.box)[t.index] or nil end
  -- reason a MOVE (not a swap) onto `tgt` would fail (nil = fine / it's a swap)
  local function isHealthy(m)
    if not m then return false end
    local hp = m.hp
    return hp == nil or hp > 0            -- box mons may store nil hp = full
  end
  local function partyHealthy()
    local n = 0
    for _, m in ipairs(arrayOf("party")) do if isHealthy(m) then n = n + 1 end end
    return n
  end
  -- reason a placement (MOVE or SWAP) would be refused (nil = allowed)
  local function placeBlocked(src, tgt)
    if not (src and tgt) then return nil end
    local sMon = arrayOf(src.loc, src.box)[src.index]
    local tMon = targetMonAt(tgt)
    local isSwap = tMon and tMon ~= sMon
    if not isSwap then         -- capacity + can't-empty-party apply to moves only
      if src.loc == "party" and tgt.loc ~= "party" and #arrayOf("party") <= 1 then return "Can't deposit your last Pokemon" end
      if tgt.loc == "party" and #arrayOf("party") >= PMAX then return "Party is full (6/6)" end
      if tgt.loc == "box" and #arrayOf("box", tgt.box) >= BCAP then return ("Box %d is full"):format(tgt.box) end
    end
    -- the party must always keep >=1 non-fainted Pokemon. Work out how many
    -- healthy mons the party would have AFTER this op; block only if it drops
    -- from >=1 to 0 (so an all-fainted party can still be rescued by a swap-in).
    local cur, res = partyHealthy(), partyHealthy()
    if src.loc == "party" and tgt.loc ~= "party" then           -- a party mon leaves
      if isHealthy(sMon) then res = res - 1 end
      if isSwap and isHealthy(tMon) then res = res + 1 end       -- swap brings a box mon in
    elseif src.loc ~= "party" and tgt.loc == "party" and isSwap then  -- party mon out, box mon in
      if isHealthy(tMon) then res = res - 1 end
      if isHealthy(sMon) then res = res + 1 end
    end
    if cur >= 1 and res < 1 then return "Keep a healthy Pokemon in your party" end
    return nil
  end
  local function doMonPlace(src, tgt)
    if not tgt then return true end
    local sArr = arrayOf(src.loc, src.box); local sMon = sArr[src.index]
    if not sMon then return false, "Nothing to move" end
    if src.loc == tgt.loc and src.box == tgt.box and src.index == tgt.index then return true end
    local blk = placeBlocked(src, tgt); if blk then return false, blk end
    local tArr = arrayOf(tgt.loc, tgt.box); local tMon = tgt.index and tArr[tgt.index]
    if tMon and tMon ~= sMon then                -- SWAP
      sArr[src.index], tArr[tgt.index] = tMon, sMon; return true
    end
    table.remove(sArr, src.index)
    local at = tgt.index
    if src.loc == tgt.loc and src.box == tgt.box and at and at > src.index then at = at - 1 end
    if at and at >= 1 and at <= #tArr + 1 then table.insert(tArr, at, sMon) else tArr[#tArr+1] = sMon end
    return true
  end
  local function ptIn(x, y, w, h) return C.mx >= x and C.mx <= x+w and C.my >= y and C.my <= y+h end
  local function railAt(dx, dy)
    for _, r in ipairs(C.pLayout.rail or {}) do if dx>=r.x and dx<=r.x+r.w and dy>=r.y and dy<=r.y+r.h then return r end end
  end
  local function monSlotAt(dx, dy)
    for _, r in ipairs(C.pLayout.party or {}) do if dx>=r.x and dx<=r.x+r.w and dy>=r.y and dy<=r.y+r.h then return { loc="party", index=r.index, mon=r.mon } end end
    for _, r in ipairs(C.pLayout.grid or {}) do if dx>=r.x and dx<=r.x+r.w and dy>=r.y and dy<=r.y+r.h then return { loc="box", box=C.pLayout.curBox, index=r.index, mon=r.mon } end end
  end
  local function dropTargetMon(dx, dy)
    local t = railAt(dx, dy); if t then return { loc="box", box=t.box } end   -- rail tab -> append to that box
    for _, r in ipairs(C.pLayout.party or {}) do if dx>=r.x and dx<=r.x+r.w and dy>=r.y and dy<=r.y+r.h then return { loc="party", index=r.index } end end
    for _, r in ipairs(C.pLayout.grid or {}) do if dx>=r.x and dx<=r.x+r.w and dy>=r.y and dy<=r.y+r.h then return { loc="box", box=C.pLayout.curBox, index=r.index } end end
  end
  local function drawSpriteIn(img, x, y, bw, bh)
    if not img then return end
    local iw, ih = img:getDimensions()
    img:setFilter("nearest", "nearest")
    local sc = math.min(bw/iw, bh/ih)
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.draw(img, (x+bw/2)*s, (y+bh/2)*s, 0, sc*s, sc*s, iw/2, ih/2)
  end
  local function heldIsAt(loc, box, index)
    local h = C.held and C.held.src
    return h and h.loc == loc and h.box == box and h.index == index
  end
  local function partyPanel(px, py, pw, ph)
    local dPoke = C.game.data.pokemon
    local party = C.game.save.party or {}
    local hs = C.held and C.held.src
    panel(px, py, pw, ph, false)
    txt("PARTY", px+PAD, py+12, 22, COL.text)
    txt(#party.."/6", px+pw-PAD, py+16, 14, COL.dim, "right")
    local ry = py + 54
    local rh = math.min(150, (ph - 64) / 6)
    C.pLayout.party = {}
    for i = 1, 6 do
      local y = ry + (i-1)*rh
      local mon = party[i]
      C.pLayout.party[#C.pLayout.party+1] = { x=px+8, y=y, w=pw-16, h=rh-6, index=i, mon=mon }
      local held = heldIsAt("party", nil, i)
      local hov = ptIn(px+8, y, pw-16, rh-6)
      local tgt = hs and hov
      local blk = tgt and placeBlocked(hs, { loc="party", index=i })
      if held then setc(COL.gold, 0.05)
      elseif tgt and blk then setc(COL.lo, 0.16)
      elseif tgt then setc(COL.hi, 0.14)
      elseif hov and mon then setc(COL.gold, 0.10)
      else setc(COL.border, mon and 0.03 or 0.012) end
      rrect("fill", px+8, y, pw-16, rh-6, 8)
      if mon then
        local def = dPoke[mon.species]
        local ss = math.min(rh-6-16, 96)
        drawSpriteIn(getSprite(mon.species, dPoke), px+PAD, y+(rh-6-ss)/2, ss, ss)
        local nx = px+PAD+ss+14
        local mx = monMax(mon, def); local hp = mon.hp or mx
        local frac = mx > 0 and hp/mx or 0
        txt(sanitize(mon.nickname or (def and def.name) or mon.species), nx, y + rh*0.16, 20, held and COL.dim or COL.text)
        txt("Lv"..(mon.level or 1), nx, y + rh*0.16 + 28, 15, COL.dim)
        bar(nx, y + rh*0.63, pw - (nx-px) - PAD, 10, frac, hpCol(frac))
        txt(hp.."/"..mx, px+pw-PAD, y + rh*0.63 - 22, 14, COL.dim, "right")
      else
        txt("- empty -", px+PAD, y+(rh-6)/2-10, 15, COL.dim, nil, 0.4)
      end
    end
  end
  local function boxPanel(px, py, pw, ph)
    local save = C.game.save
    local boxes = boxesEnsure()
    local cur = C.boxView or save.currentBox or 1
    C.pLayout.curBox = cur
    local hs = C.held and C.held.src
    panel(px, py, pw, ph, false)
    txt("BOXES", px+PAD, py+12, 22, COL.text)
    local curCount = #(boxes[cur] or {})
    txt("Box "..cur.."   "..curCount.."/"..BCAP, px+pw-PAD, py+16, 14, curCount>=BCAP and COL.lo or COL.dim, "right")
    -- rail: all 12 boxes (empty ones smaller/dimmer, current highlighted, drop targets)
    C.pLayout.rail = {}
    local ry0 = py + 46
    local tw = (pw - PAD*2 - (NBOX-1)*4) / NBOX
    local th = 46
    for n = 1, NBOX do
      local cnt = #(boxes[n] or {})
      local empty = cnt == 0
      local tx = px+PAD + (n-1)*(tw+4)
      local ty = ry0                                   -- all tabs same size + baseline
      local sel = n == cur
      local hov = ptIn(tx, ty, tw, th)
      C.pLayout.rail[#C.pLayout.rail+1] = { x=tx, y=ty, w=tw, h=th, box=n }
      local dropHi = hs and hov
      local blk = dropHi and placeBlocked(hs, { loc="box", box=n })
      setc(sel and COL.gold or (dropHi and (blk and COL.lo or COL.hi) or COL.panel), sel and 0.9 or (empty and 0.35 or 0.72))
      rrect("fill", tx, ty, tw, th, 5)
      txt(tostring(n), tx+tw/2, ty+5, 18, sel and COL.panel or (empty and COL.dim or COL.text), "center")
      txt(empty and "-" or (cnt.."/"..BCAP), tx+tw/2, ty+28, 11, sel and COL.panel or COL.dim, "center", empty and 0.5 or 0.9)
    end
    -- 4x5 grid of the current box
    local box = boxes[cur] or {}
    local gcols, grows, gap = 4, 5, 10
    local gy0 = ry0 + 46 + 16
    local cwd = (pw - PAD*2 - (gcols-1)*gap) / gcols
    local chh = math.min((ph - (gy0-py) - PAD - 6) / grows - gap, cwd*1.1)
    C.pLayout.grid = {}
    for i = 1, gcols*grows do
      local col, row = (i-1)%gcols, math.floor((i-1)/gcols)
      local tx = px+PAD + col*(cwd+gap)
      local ty = gy0 + row*(chh+gap)
      local mon = box[i]
      C.pLayout.grid[#C.pLayout.grid+1] = { x=tx, y=ty, w=cwd, h=chh, index=i, mon=mon }
      local held = heldIsAt("box", cur, i)
      local hov = ptIn(tx, ty, cwd, chh)
      local tgt = hs and hov
      local blk = tgt and placeBlocked(hs, { loc="box", box=cur, index=i })
      if held then setc(COL.gold, 0.05)
      elseif tgt and blk then setc(COL.lo, 0.16)
      elseif tgt then setc(COL.hi, 0.14)
      elseif hov and mon then setc(COL.gold, 0.12)
      else setc(COL.border, mon and 0.04 or 0.02) end
      rrect("fill", tx, ty, cwd, chh, 8)
      if mon then
        local def = C.game.data.pokemon[mon.species]
        drawSpriteIn(getSprite(mon.species, C.game.data.pokemon), tx+6, ty+2, cwd-12, chh-42)
        local nm = sanitize(mon.nickname or (def and def.name) or mon.species)
        txt(ellipsize(nm, 13, cwd-8), tx+cwd/2, ty+chh-37, 13, held and COL.dim or COL.text, "center")
        txt("Lv"..(mon.level or 1), tx+cwd/2, ty+chh-19, 12, COL.dim, "center")
      end
    end
  end
  local function drawPartyPanels(lx, rx, py, pw, ph)
    C.pLayout = C.pLayout or {}
    partyPanel(lx, py, pw, ph)
    boxPanel(rx, py, pw, ph)
  end
  local function drawHeldMon()
    local h = C.held; if not h or not h.mon then return end
    local def = C.game.data.pokemon[h.mon.species]
    local blk = placeBlocked(h.src, dropTargetMon(C.mx, C.my))
    local gx, gy = C.mx, C.my
    local w = 214
    setc(COL.panel, 0.97); rrect("fill", gx+16, gy-28, w, 58, 8)
    setc(blk and COL.lo or COL.gold, 0.9); love.graphics.setLineWidth(math.max(1, s)); rrect("line", gx+16, gy-28, w, 58, 8)
    drawSpriteIn(getSprite(h.mon.species, C.game.data.pokemon), gx+20, gy-26, 54, 54)
    txt(sanitize(h.mon.nickname or (def and def.name) or h.mon.species), gx+80, gy-20, 16, COL.text)
    txt("Lv"..(h.mon.level or 1), gx+80, gy+4, 13, COL.dim)
    if blk then txt(blk, gx+16, gy+34, 13, COL.lo)
    else txt("drop on a slot or box", gx+16, gy+34, 12, COL.gold, nil, 0.85) end
  end

  -- ---- open / close + input --------------------------------------------
  local function canOpen()
    local g = C.game
    return g and g.stack and g.overworld and g.stack:top() == g.overworld
      and g.save and g.save.party and #g.save.party > 0
  end
  local function ensureModalState()
    if not C.modalState then
      C.modalState = {
        isOpaque = false, screenId = "KantoManageScreen",
        onKeyPressed = function(_, key)
          local c = _G.__KANTO_INGAME; if c and c.onScreenKey then c.onScreenKey(key) end
        end,
        update = function() end,
        draw = function() end,
      }
    end
    return C.modalState
  end
  C.openScreen = function(kind)
    if not canOpen() then return end
    C.screen = kind
    C.held, C.status = nil, nil
    C.boxView = C.game.save.currentBox or 1
    C.stickActive, C.vcx, C.vcy, C.padDown = false, nil, nil, false
    if kind == "items" then buildItemView(); C.iscroll = { bag = 0, pc = 0 }; C.iCursor = { bag = 1, pc = 1 }; C.iOnSave = false end
    C.game.stack:push(ensureModalState())
    C.cursorWas = love.mouse.isVisible()
    love.mouse.setVisible(true)
  end
  C.closeScreen = function()
    if C.game and C.game.stack and C.game.stack:top() == C.modalState then C.game.stack:pop() end
    C.screen, C.held = false, nil
    C.stickActive, C.padDown = false, false
    if C.cursorWas ~= nil then love.mouse.setVisible(C.cursorWas) end
  end
  -- The screen cycle (used to also be reachable via Select/touchpad/Tab-
  -- Shift/a touch hot-zone) derives
  -- the next step from whatever's actually showing right now (rather than a
  -- separate counter), so it stays correct even if keyboard/other-button
  -- presses changed the state mid-cycle.
  --   forward:  nothing shown -> overlay -> items -> party -> nothing -> ...
  --   backward: nothing shown -> party -> items -> overlay -> nothing -> ...
  -- (backward is just the same ring walked the other way -- pass
  -- reverse = true, e.g. from the left touch-nav button)
  -- If a screen can't open right now (canOpen() fails, e.g. mid-battle or no
  -- party), that step is just skipped over rather than getting stuck.
  C.onPadCycle = function(reverse)
    if not reverse then
      if C.screen == "party" then
        C.closeScreen(); C.visible = false; return
      end
      if C.screen == "items" then
        C.closeScreen(); C.openScreen("party"); return
      end
      if C.visible then
        C.visible = false; C.openScreen("items"); return
      end
      C.visible = true
      return
    end
    -- reverse: walk the same ring backward
    if C.visible and not C.screen then
      C.visible = false; return
    end
    if C.screen == "items" then
      C.closeScreen(); C.visible = true; return
    end
    if C.screen == "party" then
      C.closeScreen(); C.openScreen("items"); return
    end
    C.openScreen("party")
  end
  C.onScreenKey = function(key)
    if key == "escape" then
      if C.screen == "items" and C.held then C.held = nil; return end   -- cancel a pending pickup first
      C.closeScreen(); return
    end
    if OVERLAY_KEYS[key] then   -- switch away from this screen to the overlay
      C.closeScreen(); C.visible = true; return
    end
    if key == ITEMS_KEY then
      if C.screen == "items" then C.closeScreen()
      else
        C.screen = "items"; C.held = nil; buildItemView(); C.iscroll = { bag = 0, pc = 0 }; C.iCursor = { bag = 1, pc = 1 }; C.iOnSave = false
        C.stickActive, C.vcx, C.vcy, C.padDown = false, nil, nil, false
      end
      return
    end
    if key == PARTY_KEY then
      if C.screen == "party" then C.closeScreen()
      else
        C.screen = "party"; C.held = nil; C.boxView = C.game.save.currentBox or 1
        C.stickActive, C.vcx, C.vcy, C.padDown = false, nil, nil, false
      end
      return
    end
    local nbox = (C.Boxes and C.Boxes.COUNT) or 12
    if C.screen == "party" and key == "left"  then C.boxView = (C.boxView or 1) > 1 and C.boxView-1 or nbox end
    if C.screen == "party" and key == "right" then C.boxView = (C.boxView or 1) < nbox and C.boxView+1 or 1 end
    if C.screen == "items" and key == "left"  then C.iFocus = "bag" end
    if C.screen == "items" and key == "right" then C.iFocus = "pc" end
  end
  -- Left-stick virtual cursor for the Items/Party screens. Moves C.vcx/vcy
  -- (raw pixels, same space as love.mouse.getPosition()) at a speed scaled
  -- off how far the stick is pushed past its dead-zone; C.drawScreen below
  -- substitutes this for the real mouse position (into C.mx/C.my) whenever
  -- C.stickActive is set, which is ALL this needs to do to work -- every
  -- pickup/drag/drop/sort/box-tab/close rule in onScreenMouse/onScreenRelease
  -- already runs purely off C.mx/C.my and a button-down/up pair, so routing
  -- the A button through those same two functions (see love.gamepadpressed/
  -- gamepadreleased further down) gets the whole Items AND Party screen --
  -- including Party's Pokemon grab/drop, which real D-pad/A never covered --
  -- for free, with nothing about the rules duplicated here.
  --
  -- Stick control only takes over once the stick actually gets pushed
  -- (C.stickActive starts false whenever a screen opens or switches -- see
  -- C.openScreen/C.onScreenKey above), and immediately hands back to
  -- D-pad/A/B or mouse/touch the moment either of those is used instead
  -- (see the dpad branch in love.gamepadpressed and the mousepressed
  -- wrapper) -- so all three input styles stay fully usable side by side,
  -- same as D-pad/A/B and mouse/touch already were.
  C.updateStickCursor = function(dt)
    if not C.screen then return end
    local lx, ly = 0, 0
    for _, j in ipairs(love.joystick.getJoysticks()) do
      if j:isGamepad() then
        local jx, jy = j:getGamepadAxis("leftx"), j:getGamepadAxis("lefty")
        if math.abs(jx) > 0.15 or math.abs(jy) > 0.15 then lx, ly = jx, jy; break end
        if lx == 0 and ly == 0 then lx, ly = jx, jy end   -- fall back to the first pad if none are pushed
      end
    end
    local DEADZONE = 0.22
    local mag = math.sqrt(lx*lx + ly*ly)
    if mag <= DEADZONE then return end
    C.stickActive = true
    local nx, ny = lx / mag, ly / mag                              -- unit direction
    local pull = math.min(1, (mag - DEADZONE) / (1 - DEADZONE))    -- 0..1 eased past the dead-zone
    local W, H = love.graphics.getDimensions()
    local speed = H * 0.9   -- design: ~1s to cross the window height at full deflection
    C.vcx = math.max(0, math.min(W, (C.vcx or W/2) + nx * pull * speed * (dt or 0)))
    C.vcy = math.max(0, math.min(H, (C.vcy or H/2) + ny * pull * speed * (dt or 0)))
  end
  C.onScreenWheel = function(_, dy)
    if C.screen == "party" then
      local nbox = (C.Boxes and C.Boxes.COUNT) or 12
      if dy > 0 then C.boxView = (C.boxView or 1) > 1 and C.boxView-1 or nbox
      elseif dy < 0 then C.boxView = (C.boxView or 1) < nbox and C.boxView+1 or 1 end
      return
    end
    if C.screen ~= "items" then return end
    if C.held and C.held.max and C.held.max > 1 then     -- adjust the carried quantity
      C.held.qty = math.max(1, math.min(C.held.max, C.held.qty + (dy > 0 and 1 or -1)))
      return
    end
    local side = (C.iLayout.bag and C.mx <= C.iLayout.bag.x + C.iLayout.bag.w) and "bag" or "pc"
    local L = C.iLayout[side]
    if L then
      local maxScroll = math.max(0, (L.contentH or 0) - L.h)
      C.iscroll[side] = math.max(0, math.min(maxScroll, (C.iscroll[side] or 0) - dy * 64))
    end
  end
  -- Controller equivalent of the mouse wheel on the Items screen. A D-pad
  -- press has no cursor position to hover a side with, so it acts on
  -- whichever side is currently focused (C.iFocus, toggled by D-pad left/right).
  --
  -- Up/down always moves a row cursor (C.iCursor) through the focused side's
  -- list, one item at a time, auto-scrolling the panel to keep the
  -- highlighted row in view -- this includes the side a held item came from,
  -- which is what lets the D-pad reorder in place instead of only
  -- transferring to the other side. Quantity for a held stack is adjusted
  -- with the L2/R2 triggers instead (C.onPadTrigger), so up/down stays free
  -- for positioning even a multi-item stack. Press A (C.onPadSelect) to pick
  -- up the highlighted item, then D-pad to wherever it should land --
  -- including one slot past the last item, to drop it at the end of the
  -- list -- and A again to drop it there.
  C.onPadScroll = function(dy)
    if C.screen ~= "items" then return end
    local side = C.iFocus or "bag"
    -- "Save order" sits in the Bag's header, above the item list, and is
    -- only reachable by pad while browsing (nothing held, since a held item
    -- has its own drop-target meaning for this side). D-pad up from the top
    -- row selects it; down from it drops back into the list at row 1.
    if side == "bag" and not C.held then
      if C.iOnSave then
        if dy < 0 then C.iOnSave = false; C.iCursor.bag = 1 end
        return
      elseif dy > 0 and (C.iCursor.bag or 1) <= 1 then
        C.iOnSave = true
        return
      end
    end
    local rows = itemRows(side)
    if #rows == 0 then return end
    -- While held, the cursor can go one past the last row to mean "drop at
    -- the end of the list" -- true for either side now.
    local maxCur = C.held and (#rows + 1) or #rows
    local cur = math.max(1, math.min(maxCur, (C.iCursor[side] or 1) + (dy > 0 and -1 or 1)))
    C.iCursor[side] = cur
    local L = C.iLayout[side]
    if L then
      local off, ih = itemContentOffset(side, cur)
      local scroll = C.iscroll[side] or 0
      if off < scroll then scroll = off
      elseif off + ih > scroll + L.h then scroll = off + ih - L.h end
      local maxScroll = math.max(0, (L.contentH or 0) - L.h)
      C.iscroll[side] = math.max(0, math.min(maxScroll, scroll))
    end
  end
  -- L2/R2 triggers on the Items screen: adjust the quantity of a held stack,
  -- same step as the mouse wheel. Split out from D-pad up/down so that stays
  -- free to move the cursor -- and choose a drop position -- even while
  -- carrying more than one of an item.
  C.onPadTrigger = function(dir)
    if C.screen ~= "items" then return end
    if not (C.held and C.held.max and C.held.max > 1) then return end
    C.held.qty = math.max(1, math.min(C.held.max, C.held.qty + dir))
  end
  -- A button on the Items screen: with nothing held, picks up the row under
  -- the D-pad cursor on the focused side (armed immediately, no drag
  -- needed). With something held, drops it at the cursor on whichever side
  -- is currently focused -- the source side included, so this is also how
  -- the D-pad reorders within a side: move the cursor to the target row, A
  -- to drop it there (landing back on its own row is a no-op). B/Esc cancels
  -- a pending pickup instead of A.
  C.onPadSelect = function()
    if C.screen ~= "items" then return end
    local side = C.iFocus or "bag"
    if not C.held then
      if side == "bag" and C.iOnSave then
        if isDirty("bag") then applyOrder("bag") end
        return
      end
      local rows = itemRows(side)
      local r = rows[C.iCursor[side] or 1]
      if not r then return end
      if side == "bag" and isBadgeItem(r.id) then return end
      local full = invOf(side)[r.id] or 1
      C.held = { from = side, id = r.id, qty = full, max = full, mode = "armed", pad = true, downX = 0, downY = 0 }
    elseif C.held.mode == "armed" then
      local rows = itemRows(side)
      local beforeId = rows[C.iCursor[side] or 1] and rows[C.iCursor[side] or 1].id or nil
      local ok, err = doTransfer(C.held.from, C.held.id, C.held.qty, side, beforeId)
      if not ok then C.status = err end
      C.held = nil
    end
  end
  local function topHit(dx, dy)
    for i = #C.hit, 1, -1 do
      local r = C.hit[i]
      if dx >= r.x and dx <= r.x+r.w and dy >= r.y and dy <= r.y+r.h then return r.tag, r.data end
    end
  end
  C.onScreenMouse = function(px, py, button)   -- mouse DOWN
    if not C.screen then return end
    s = (love.graphics.getHeight() / REF_H) * UI_SCALE_SCREEN
    if button == 2 then C.held = nil; return end
    local dx, dy = px/s, py/s
    local tag, data = topHit(dx, dy)
    if tag == "close" then C.closeScreen(); return end
    if C.screen == "party" then
      if C.held and C.held.mode == "armed" then          -- placing an armed mon
        local tgt = dropTargetMon(dx, dy)
        if tgt then local ok, err = doMonPlace(C.held.src, tgt); if not ok and err then C.status = err end end
        C.held = nil; return
      end
      local slot = monSlotAt(dx, dy)
      if slot and slot.mon then                            -- grab a Pokemon
        C.held = { mon = slot.mon, src = { loc = slot.loc, box = slot.box, index = slot.index },
                   mode = "pending", downX = dx, downY = dy }
        return
      end
      local tab = railAt(dx, dy)
      if tab then C.boxView = tab.box; return end          -- click a box tab -> view it
      C.held = nil
      return
    end
    -- ITEMS ------------------------------------------------------------
    if tag == "sort"  then C.held = nil; sortSide(data.side, data.mode); return end
    if tag == "apply" then C.held = nil; applyOrder(data); return end
    if C.held and C.held.mode == "armed" then     -- placing an armed item
      local tside, tidx = dropTarget(dx, dy)
      if tside then local ok, err = doTransfer(C.held.from, C.held.id, C.held.qty, tside, tidx); if not ok then C.status = err end end
      C.held = nil; return
    end
    if tag == "itemrow" and not (data.side == "bag" and isBadgeItem(data.id)) then
      local full = invOf(data.side)[data.id] or 1
      C.held = { from = data.side, id = data.id, qty = full, max = full, mode = "pending", downX = dx, downY = dy }
      return
    end
    C.held = nil
  end
  C.onScreenRelease = function(px, py, button)   -- mouse UP
    if not C.screen or not C.held or button ~= 1 then return end
    s = (love.graphics.getHeight() / REF_H) * UI_SCALE_SCREEN
    local dx, dy = px/s, py/s
    if C.screen == "items" then
      if C.held.mode == "drag" then
        local tside, bId = dropTarget(dx, dy)
        if tside then local ok, err = doTransfer(C.held.from, C.held.id, C.held.qty, tside, bId); if not ok then C.status = err end end
        C.held = nil
      elseif C.held.mode == "pending" then C.held.mode = "armed" end
    elseif C.screen == "party" then
      if C.held.mode == "drag" then
        local tgt = dropTargetMon(dx, dy)
        if tgt then local ok, err = doMonPlace(C.held.src, tgt); if not ok and err then C.status = err end end
        C.held = nil
      elseif C.held.mode == "pending" then C.held.mode = "armed" end
    end
  end
  C.drawScreen = function()
    if not C.screen or not (C.game and C.game.save) then return end
    local W, H = love.graphics.getDimensions()
    s = (H / REF_H) * UI_SCALE_SCREEN
    local fullH = H / s     -- actual design-space canvas height at this scale (REF_H only when UI_SCALE_SCREEN = 1)
    C.hit = {}
    if C.stickActive then
      C.mx, C.my = (C.vcx or W/2)/s, (C.vcy or H/2)/s
    else
      local rmx, rmy = love.mouse.getPosition(); C.mx, C.my = rmx/s, rmy/s
    end
    -- promote a pending press to a drag once the cursor moves past a threshold
    if C.held and C.held.mode == "pending" and (love.mouse.isDown(1) or C.padDown) then
      local ddx, ddy = C.mx - C.held.downX, C.my - C.held.downY
      if ddx*ddx + ddy*ddy > 196 then C.held.mode = "drag" end
    end
    love.graphics.push("all"); love.graphics.origin()
    setc({0,0,0}, 0.72); love.graphics.rectangle("fill", 0, 0, W, H)
    local fullW = W / s
    local M, headerH = 40, 74
    local maxW = 1180
    local contentW = math.min(fullW - 2*M, maxW)
    -- Normally a small fixed gap between the two panels. When the touch nav
    -- buttons are on (TOUCH_NAV_LEFT/RIGHT near the top of the file), widen
    -- it so neither panel's edge sits under a button -- computed from the
    -- same percent-of-window button zones, converted into this screen's
    -- design-space units, so it stays correct across any window size the
    -- same way the buttons themselves do, and automatically tracks if those
    -- zones are ever repositioned/resized.
    local G = 26
    if mod.options:get("touch_nav_buttons") then
      local navPad = 14  -- design-space breathing room beyond each button's outer edge
      local navHalfGap = math.max(0.5 - TOUCH_NAV_LEFT.x1, TOUCH_NAV_RIGHT.x2 - 0.5) * fullW + navPad
      G = math.max(G, navHalfGap * 2)
      G = math.min(G, contentW - 240)  -- safety floor: keep each panel at least 120 design units wide
    end
    local ox = (fullW - contentW) / 2      -- centre the whole layout
    local pw = (contentW - G) / 2
    -- Footer hint/status text wraps to fit contentW instead of running off
    -- the right edge; footerH is sized off however many lines that actually
    -- takes this frame, so it never gets cut off regardless of message length.
    local footerSize, footerLineH = 16, 20
    local hint = C.screen == "items"
      and "Drag to transfer or reorder. D-Pad up/down to highlight an item, A to pick it up (or push the left stick for a free cursor). Move to any position or side and drop with A. L2/R2 to adjust quantity. B to cancel or exit."
      or  "Drag a Pokemon onto a slot or box tab (onto an occupied slot = swap), or push the left stick for a free cursor and A to grab/drop  -  D-Pad / click a tab changes box  -  Esc closes"
    local footerLines = wrapText(C.status or hint, footerSize, contentW)
    local footerH = 16 + #footerLines * footerLineH
    local py = M + headerH
    local ph = fullH - py - footerH - M
    local lx, rx = ox, ox + pw + G
    txt(C.screen == "items" and "ITEMS      Bag  <->  PC"
                             or "POKEMON      Party  <->  Boxes", ox, M+16, 30, COL.gold)
    local cw = 44; local cx, cy = ox+contentW-cw, M+6
    local hovX = region(cx, cy, cw, cw, "close")
    setc(hovX and COL.lo or COL.panel, 0.95); rrect("fill", cx, cy, cw, cw, 10)
    setc(COL.border, 0.3); rrect("line", cx, cy, cw, cw, 10)
    txt("X", cx+cw/2, cy+7, 24, COL.text, "center")
    if C.screen == "items" then
      drawItemsPanels(lx, rx, py, pw, ph)
      if C.held then drawHeldItem() end
    else
      drawPartyPanels(lx, rx, py, pw, ph)
      if C.held then drawHeldMon() end
    end
    local footerCx = ox + contentW/2
    for i, line in ipairs(footerLines) do
      txt(line, footerCx, fullH - footerH + 8 + (i-1)*footerLineH, footerSize, C.status and COL.mid or COL.dim, "center")
    end
    -- Left-stick virtual cursor (see C.updateStickCursor/C.stickActive):
    -- only drawn while it's actually the thing in control, so it doesn't
    -- show a phantom cursor while D-pad or mouse/touch are being used.
    if C.stickActive then
      setc(COL.gold, 0.9)
      love.graphics.setLineWidth(2)
      love.graphics.circle("line", C.mx*s, C.my*s, 10*s)
      love.graphics.circle("fill", C.mx*s, C.my*s, 2*s)
      love.graphics.setLineWidth(1)
    end
    love.graphics.pop()
  end

  -- ---------------------------------------------------------------------
  -- Fit-to-screen helpers. A 7" panel has much less vertical room than the
  -- 1440p layout was designed against, so a full 6-mon party (or a battle
  -- readout with several catch-odds rows) can run past the bottom edge.
  -- Both columns below are measured with a "dry run" (drawn into a
  -- zero-size scissor, so nothing is actually visible) to get their real
  -- height for THIS frame's data, then -- only if that height doesn't fit
  -- -- redrawn for real inside a uniform scale-down transform anchored to
  -- the column's top-left corner. Content that already fits is completely
  -- unaffected (scale stays 1, no visual change at all).
  -- ---------------------------------------------------------------------
  local MIN_FIT_SCALE = 0.72   -- never shrink further than this; readability floor
  local function dryRun(fn, ...)
    love.graphics.push("all")
    love.graphics.setScissor(0, 0, 0, 0)   -- zero-area clip: draws happen but nothing renders
    local h = fn(...)
    love.graphics.setScissor()             -- explicitly clear (matches this file's scissor convention below)
    love.graphics.pop()
    return h
  end
  local function drawScaled(px, py, scale, fn, ...)
    if scale >= 1 then fn(...); return end
    love.graphics.push()
    love.graphics.translate(px * s, py * s)
    love.graphics.scale(scale)
    love.graphics.translate(-px * s, -py * s)
    fn(...)
    love.graphics.pop()
  end

  -- ---------------------------------------------------------------------
  -- Compose: draw everything, anchored to the window edges (widescreen).
  -- ---------------------------------------------------------------------
  C.drawOverlay = function()
    if not C.visible or C.screen then return end
    local st = C.state
    if not st or not st.active then return end
    -- Hold the WHOLE overlay until a real game is in play. The engine makes a
    -- default (empty-party) save at the launcher/title, which would otherwise
    -- flash the trainer/route panels before you've loaded a game. Gate on the
    -- party -- once it has a mon, everything shows together.
    if not (st.party and #st.party > 0) then return end
    local W, H = love.graphics.getDimensions()
    s = (H / REF_H) * UI_SCALE_OVERLAY
    -- With touch nav on, the overlay panels sit on top of the touch controls
    -- and hide them, so render the whole overlay to an offscreen canvas and
    -- composite it back at reduced alpha. That dims it as a single flat
    -- image -- the touch pad shows through uniformly, and every panel keeps
    -- its own internal contrast (text still reads against its background)
    -- instead of each draw call getting faded individually. Off (the
    -- default) draws straight to the screen exactly as before -- no canvas,
    -- no alpha change.
    local dimOverlay = mod.options:get("touch_nav_buttons")
    if dimOverlay then
      if not overlayCanvas or overlayCanvas:getWidth() ~= W or overlayCanvas:getHeight() ~= H then
        overlayCanvas = love.graphics.newCanvas(W, H)
      end
      love.graphics.push("all")
      love.graphics.setCanvas(overlayCanvas)
      love.graphics.clear(0, 0, 0, 0)
    else
      love.graphics.push("all")
    end
    love.graphics.origin()
    local margin = 28
    -- Design-space canvas height is always REF_H / UI_SCALE_OVERLAY, no
    -- matter the real window size (s is derived from H so the two cancel
    -- out) -- so this is the real amount of vertical room either column has.
    local availH = (REF_H / UI_SCALE_OVERLAY) - margin * 2

    -- LEFT: party. Prefer the configured density (C.partyStyle) at full
    -- size; if a full party doesn't fit, shrink it uniformly; if it would
    -- have to shrink past the readability floor, drop to the compact
    -- density instead (which still shows every mon, just without move lists).
    local pStyle = C.partyStyle or 1
    local natH = dryRun(party, st, margin, margin, pStyle)
    local pScale = 1
    if natH > availH then
      pScale = availH / natH
      if pScale < MIN_FIT_SCALE and pStyle == 1 then
        pStyle = 2
        natH = dryRun(party, st, margin, margin, pStyle)
        pScale = natH > availH and math.max(availH / natH, MIN_FIT_SCALE) or 1
      else
        pScale = math.max(pScale, MIN_FIT_SCALE)
      end
    end
    drawScaled(margin, margin, pScale, party, st, margin, margin, pStyle)

    -- RIGHT: trainer + items + (route or battle), same idea -- measured as
    -- one stack so it never runs off the bottom, however many badges,
    -- items, threats, or catch-odds rows this frame happens to have.
    local rx = (W / s) - COLW - margin
    local function rightColumn()
      local ry = margin
      ry = ry + trainer(st, rx, ry) + 16
      local ih = items(st, rx, ry)
      if ih > 0 then ry = ry + ih + 16 end
      local bh = st.battle and battle(st, rx, ry) or route(st, rx, ry)
      return (ry + bh) - margin
    end
    local rNatH = dryRun(rightColumn)
    local rScale = rNatH > availH and math.max(availH / rNatH, MIN_FIT_SCALE) or 1
    drawScaled(rx, margin, rScale, rightColumn)
    love.graphics.pop()
    if dimOverlay then
      love.graphics.push("all")
      love.graphics.origin()
      love.graphics.setCanvas()
      love.graphics.setColor(1, 1, 1, 0.62)
      love.graphics.draw(overlayCanvas, 0, 0)
      love.graphics.setColor(1, 1, 1, 1)
      love.graphics.pop()
    end
  end

  -- Draws the two transparent left/right touch-nav buttons (see
  -- TOUCH_NAV_LEFT/RIGHT above) when the "TOUCH SCREEN NAV BUTTONS" mod
  -- option is on. Semi-transparent rounded rect + arrow so it reads clearly
  -- over any part of the game without blocking much underneath it. Purely
  -- visual pairing for TOUCH_NAV_LEFT/RIGHT -- the actual tap handling lives
  -- in the love.touchpressed wrapper further down.
  C.drawTouchNav = function()
    if not mod.options:get("touch_nav_buttons") then return end
    local ww, wh = love.graphics.getDimensions()
    if ww <= 0 or wh <= 0 then return end
    local function drawBtn(zone, dir)
      local x1, y1 = zone.x1 * ww, zone.y1 * wh
      local x2, y2 = zone.x2 * ww, zone.y2 * wh
      local w, h = x2 - x1, y2 - y1
      love.graphics.setColor(1, 1, 1, 0.12)
      love.graphics.rectangle("fill", x1, y1, w, h, 8, 8)
      love.graphics.setColor(1, 1, 1, 0.35)
      love.graphics.rectangle("line", x1, y1, w, h, 8, 8)
      local cx, cy = x1 + w / 2, y1 + h / 2
      local aw, ah = w * 0.28, h * 0.4
      love.graphics.setColor(1, 1, 1, 0.75)
      if dir < 0 then
        love.graphics.polygon("fill", cx + aw / 2, cy - ah / 2, cx + aw / 2, cy + ah / 2, cx - aw / 2, cy)
      else
        love.graphics.polygon("fill", cx - aw / 2, cy - ah / 2, cx - aw / 2, cy + ah / 2, cx + aw / 2, cy)
      end
    end
    drawBtn(TOUCH_NAV_LEFT, -1)
    drawBtn(TOUCH_NAV_RIGHT, 1)
    love.graphics.setColor(1, 1, 1, 1)
  end

  -- ---------------------------------------------------------------------
  -- Hooks (guarded so hot-reload doesn't double-wrap)
  -- ---------------------------------------------------------------------
  if not C.wrappedUpdate and C.game and C.game.update then
    C.origUpdate = C.game.update
    C.game.update = function(self, dt)
      C.origUpdate(self, dt)
      local c = _G.__KANTO_INGAME; if c and c.onFrame then pcall(c.onFrame, dt) end
    end
    C.wrappedUpdate = true
  end
  if not C.wrappedDraw then
    C.origDraw = love.draw
    love.draw = function(...)
      if C.origDraw then C.origDraw(...) end
      local c = _G.__KANTO_INGAME
      if c and c.drawOverlay then
        local ok, err = pcall(c.drawOverlay)
        if not ok and err ~= c.drawErr then c.drawErr = err; mod.log:error("kanto_ingame draw: %s", tostring(err)) end
      end
      if c and c.screen and c.drawScreen then
        local ok, err = pcall(c.drawScreen)
        if not ok and err ~= c.screenErr then c.screenErr = err; mod.log:error("kanto_ingame screen: %s", tostring(err)) end
      end
      if c and c.drawTouchNav then
        local ok, err = pcall(c.drawTouchNav)
        if not ok and err ~= c.touchNavErr then c.touchNavErr = err; mod.log:error("kanto_ingame touch nav: %s", tostring(err)) end
      end
      -- On-screen input debug readout: no PC to view logs from an Android
      -- handheld, so this prints the last raw key/gamepad/touch event LOVE
      -- delivered, right on the screen. Shows for a few seconds after each
      -- event, small and out of the way in the bottom-left corner. Set
      -- toggle it off in the mod manager (Options > Kanto Companion) once you're
      -- done positioning/troubleshooting touch controls.
      if c and c.debugLast and c.debugLastAt and (love.timer.getTime() - c.debugLastAt) < 6 and mod.options:get("debug_input_hud") then
        local ww, wh = love.graphics.getDimensions()
        love.graphics.setColor(0, 0, 0, 0.55)
        love.graphics.rectangle("fill", 6, wh - 26, 260, 20)
        love.graphics.setColor(1, 1, 0.4, 0.95)
        love.graphics.print("last input -> " .. c.debugLast, 10, wh - 24)
        love.graphics.setColor(1, 1, 1, 1)
      end
    end
    C.wrappedDraw = true
  end
  -- Key handling lives in a C.* function that is REASSIGNED every load, so an
  -- F5 hot-reload picks up changes. The wrapper below is installed once and just
  -- delegates here (returning true = handled/consumed).
  C.onKeyDown = function(_, key)
    local c = _G.__KANTO_INGAME
    if c and not c.screen then     -- open/toggle only from the plain overworld
      if OVERLAY_KEYS[key] then c.visible = not c.visible; return true end
      if key == ITEMS_KEY and c.openScreen then c.visible = false; c.openScreen("items"); return true end
      if key == PARTY_KEY and c.openScreen then c.visible = false; c.openScreen("party"); return true end
    end
    return false  -- when a screen is open the pushed state captures keys itself
  end
  if not C.wrappedKeys and C.game and C.game.keypressed then
    C.origKeypressed = C.game.keypressed
    C.game.keypressed = function(self, key, ...)
      local c = _G.__KANTO_INGAME
      if c then c.debugLast = "key: " .. tostring(key); c.debugLastAt = love.timer.getTime() end
      if c and c.onKeyDown and c.onKeyDown(self, key) then return end
      return C.origKeypressed(self, key, ...)
    end
    C.wrappedKeys = true
  end
  if not C.wrappedMouse then
    C.origMousepressed = love.mousepressed
    love.mousepressed = function(x, y, button, ...)
      local c = _G.__KANTO_INGAME
      if c and c.screen and c.onScreenMouse then c.stickActive = false; pcall(c.onScreenMouse, x, y, button); return end
      if C.origMousepressed then return C.origMousepressed(x, y, button, ...) end
    end
    C.origMousereleased = love.mousereleased
    love.mousereleased = function(x, y, button, ...)
      local c = _G.__KANTO_INGAME
      if c and c.screen then if c.onScreenRelease then pcall(c.onScreenRelease, x, y, button) end; return end
      if C.origMousereleased then return C.origMousereleased(x, y, button, ...) end
    end
    C.origWheel = love.wheelmoved
    love.wheelmoved = function(dx, dy, ...)
      local c = _G.__KANTO_INGAME
      if c and c.screen and c.onScreenWheel then pcall(c.onScreenWheel, dx, dy); return end
      if C.origWheel then return C.origWheel(dx, dy, ...) end
    end
    C.wrappedMouse = true
  end
  if not C.wrappedTouch then
    -- Drives the touch-nav buttons (see TOUCH_NAV_LEFT/RIGHT and
    -- C.drawTouchNav) and reports raw touches to the debug HUD. Otherwise
    -- doesn't consume the event -- so it never interferes with the game's
    -- own touch handling.
    C.origTouchpressed = love.touchpressed
    love.touchpressed = function(id, x, y, ...)
      local c = _G.__KANTO_INGAME
      if c then
        -- Report position both in raw pixels and as a percentage of the
        -- current window size (x/ww, y/wh). Percentage is what actually
        -- transfers across devices/resolutions -- e.g. "same corner of the
        -- screen" on a 1920x1080 panel and a 1280x720 one are different raw
        -- pixel coordinates but the same percentage -- which is why
        -- TOUCH_NAV_LEFT/RIGHT below are defined the same way.
        local ww, wh = love.graphics.getDimensions()
        local px, py = 0, 0
        if ww > 0 and wh > 0 then px, py = x / ww * 100, y / wh * 100 end
        c.debugLast = string.format("touch: %d,%d (%.1f%%,%.1f%% of %dx%d)", math.floor(x), math.floor(y), px, py, ww, wh)
        c.debugLastAt = love.timer.getTime()
        -- Custom touch-nav buttons (drawn by C.drawTouchNav): buttons the
        -- mod itself renders on otherwise-empty screen space, so a hit here
        -- is consumed (not forwarded to the underlying game) rather than
        -- passed through.
        if mod.options:get("touch_nav_buttons") and c.onPadCycle and ww > 0 and wh > 0 then
          local zx, zy = x / ww, y / wh
          local function inZone(z) return zx >= z.x1 and zx <= z.x2 and zy >= z.y1 and zy <= z.y2 end
          if inZone(TOUCH_NAV_LEFT) then
            c.onPadCycle(true); return
          elseif inZone(TOUCH_NAV_RIGHT) then
            c.onPadCycle(false); return
          end
        end
      end
      if C.origTouchpressed then return C.origTouchpressed(id, x, y, ...) end
    end
    C.wrappedTouch = true
  end
  if not C.wrappedPad then
    C.origGamepadpressed = love.gamepadpressed
    love.gamepadpressed = function(joystick, button)
      local c = _G.__KANTO_INGAME
      if c then c.debugLast = "pad: " .. tostring(button); c.debugLastAt = love.timer.getTime() end
      if c and (button == "dpup" or button == "dpdown" or button == "dpleft" or button == "dpright") then
        c.stickActive = false   -- D-pad press hands control back from the stick cursor
      end
      -- Left-stick cursor mode (see C.updateStickCursor/C.stickActive): A
      -- becomes a mouse-button-1 press at the virtual cursor, running the
      -- exact same onScreenMouse logic a real click would -- this is what
      -- covers the Party screen too, since C.onPadSelect below only ever
      -- handled Items. C.padDown lets C.drawScreen's existing pending->drag
      -- promotion (normally keyed off love.mouse.isDown(1)) treat a held A
      -- the same way as a held mouse button.
      if c and c.screen and c.stickActive and button == "a" then
        c.padDown = true
        if c.onScreenMouse then pcall(c.onScreenMouse, c.vcx or 0, c.vcy or 0, 1) end
        return
      end
      if c and c.screen == "items" and c.onPadScroll and (button == "dpup" or button == "dpdown") then
        c.onPadScroll(button == "dpup" and 1 or -1); return
      end
      if c and c.screen == "items" and c.onPadSelect and button == "a" then
        c.onPadSelect(); return
      end
      local key = PAD_KEYMAP[button]
      if c and key then
        if c.screen then
          if c.onScreenKey then c.onScreenKey(key); return end
        elseif c.onKeyDown then
          if c.onKeyDown(nil, key) then return end
        end
      end
      if C.origGamepadpressed then return C.origGamepadpressed(joystick, button) end
    end
    -- Release side of the left-stick cursor's A-button click above -- LOVE
    -- has no prior hook here to preserve, so this one's new rather than
    -- wrapping something existing.
    C.origGamepadReleased = love.gamepadreleased
    love.gamepadreleased = function(joystick, button)
      local c = _G.__KANTO_INGAME
      if c and c.screen and button == "a" and c.padDown then
        c.padDown = false
        if c.onScreenRelease then pcall(c.onScreenRelease, c.vcx or 0, c.vcy or 0, 1) end
        return
      end
      if C.origGamepadReleased then return C.origGamepadReleased(joystick, button) end
    end
    -- L2/R2 are analog triggers, not GamepadButtons -- LOVE reports them as
    -- axes ("triggerleft"/"triggerright", 0..1), so a press is a threshold
    -- crossing rather than a button event. C.triggerDown latches each one so
    -- holding the trigger down doesn't keep firing every axis update; it
    -- resets once the axis falls back below the threshold (release).
    -- R2 (triggerright) does double duty, same as most of the other inputs
    -- in this file: on the Items screen it adjusts a held stack's quantity
    -- (unchanged, since that's the one screen where something might already
    -- be held); everywhere else -- the overworld, or the Party screen -- it
    -- opens/toggles the overlay, the same as X/Y already switch straight to
    -- Items/Party from wherever they're pressed. L2 (triggerleft) is
    -- untouched -- it still only does anything on the Items screen.
    C.origGamepadAxis = love.gamepadaxis
    love.gamepadaxis = function(joystick, axis, value)
      local c = _G.__KANTO_INGAME
      if c and (axis == "triggerleft" or axis == "triggerright")
         and (c.screen == "items" or axis == "triggerright") then
        c.triggerDown = c.triggerDown or {}
        local wasDown = c.triggerDown[axis]
        local isDown = value > 0.5
        c.triggerDown[axis] = isDown
        if isDown and not wasDown then
          if c.screen == "items" and c.onPadTrigger then
            c.onPadTrigger(axis == "triggerright" and 1 or -1)
          elseif axis == "triggerright" then
            if c.screen and c.onScreenKey then
              c.onScreenKey("o")   -- from Party, switch straight to the overlay
            elseif c.onKeyDown then
              c.onKeyDown(nil, "o")   -- from the overworld, toggle the overlay
            end
          end
        end
        return
      end
      if C.origGamepadAxis then return C.origGamepadAxis(joystick, axis, value) end
    end
    C.wrappedPad = true
  end

  mod.log:info("kanto_companion: overlay=o/R2  items=i/X  party=p/Y  cycle=touch-nav-buttons (see mod options)  (Esc/B closes a screen)  [debug input HUD: %s]", tostring(mod.options:get("debug_input_hud")))
end
